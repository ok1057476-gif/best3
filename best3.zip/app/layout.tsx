import { Analytics } from '@vercel/analytics/next'
import type { Metadata, Viewport } from 'next'
import { Inter, Patrick_Hand } from 'next/font/google'
import './globals.css'

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' })
const patrickHand = Patrick_Hand({ subsets: ['latin'], weight: '400', variable: '--font-patrick-hand' })

export const metadata: Metadata = {
  title: 'Phenom Workbench — Build your first gadget',
  description: 'Describe or sketch a gadget idea and get a friendly shopping list, step guide, and code.',
  generator: 'v0.app',
  icons: {
    icon: [
      { url: '/icon-light-32x32.png', media: '(prefers-color-scheme: light)' },
      { url: '/icon-dark-32x32.png', media: '(prefers-color-scheme: dark)' },
      { url: '/icon.svg', type: 'image/svg+xml' },
    ],
    apple: '/apple-icon.png',
  },
}

export const viewport: Viewport = {
  colorScheme: 'light dark',
  themeColor: '#FDFBF7',
}

// Runs before first paint so the saved theme is applied without a light-mode flash.
const themeInitScript = `(function(){try{var p=localStorage.getItem('phenom_theme_v1');var d=p==='dark'||p==='accent'||((p!=='light')&&window.matchMedia('(prefers-color-scheme: dark)').matches);var r=document.documentElement;r.classList.add(d?'dark':'light');if(p==='accent')r.classList.add('theme-accent');r.style.colorScheme=d?'dark':'light';var a=localStorage.getItem('phenom_accent_color_v2');if(a&&/^#[0-9a-f]{6}$/i.test(a))r.style.setProperty('--phenom-accent',a);var m=document.querySelector('meta[name="theme-color"]');if(m)m.setAttribute('content',d?'#000000':'#FDFBF7');}catch(e){document.documentElement.classList.add('light');}})();`

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" suppressHydrationWarning className={`${inter.variable} ${patrickHand.variable} bg-background`}>
      <head>
        <script dangerouslySetInnerHTML={{ __html: themeInitScript }} />
      </head>
      <body className="antialiased">
        {children}
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
