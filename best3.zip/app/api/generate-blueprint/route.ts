import { NextResponse } from 'next/server';
import { generateText, Output, type ModelMessage } from 'ai';
import { z } from 'zod';
import { STEP_ACTIONS, STEP_PART_KINDS, type Blueprint } from '@/types/blueprint';
import { buildMockBlueprint } from '@/lib/mock-blueprint';

export const maxDuration = 60;

const MODEL_ID = 'google/gemini-3-flash';

const partSchema = z.object({
  name: z.string(),
  quantity: z.number().int().min(1),
  estimatedPriceUsd: z.number().min(0),
  note: z.string().nullable(),
});

const blueprintSchema = z.object({
  title: z.string(),
  tagline: z.string(),
  difficulty: z.enum(['Beginner', 'Intermediate']),
  estimatedTime: z.string(),
  parts: z.object({
    electronics: z.array(partSchema),
    enclosureCraft: z.array(partSchema),
  }),
  steps: z
    .array(
      z.object({
        phase: z.string().describe('Short phase name grouping 3-6 consecutive steps, e.g. "Prep & Cutting".'),
        title: z.string(),
        description: z.string(),
        tip: z.string().nullable(),
        durationMinutes: z.number().int().min(1),
        action: z.enum(STEP_ACTIONS).describe('The main physical motion of this step.'),
        parts: z
          .array(
            z.object({
              label: z.string().describe('Short callout label, e.g. "Panel A", "Screws", "Servo".'),
              kind: z.enum(STEP_PART_KINDS),
              quantity: z.number().int().min(1),
            })
          )
          .min(1)
          .max(4)
          .describe('Only the parts physically handled in this step.'),
      })
    )
    .min(3),
  code: z.object({
    language: z.string(),
    filename: z.string(),
    source: z.string(),
  }),
});

const SYSTEM_PROMPT = `You design maker projects (microcontrollers + simple craft enclosures) for absolute beginners.

Step rules:
- There is NO fixed step count. Scale the number of steps to the real complexity of the build: a tiny project may need 5-7 steps, a complex one 15-30 or more.
- Each step is one physical action a beginner can finish safely in roughly 5-20 minutes. Split anything bigger.
- Include safety steps where relevant (unplug power before wiring, hot glue care, cutting away from your body, checking polarity).
- Steps must be strictly sequential; never require a later step's result.
- Group consecutive steps into logical phases of 3-6 steps (e.g. "Prep & Cutting", "Wiring", "Enclosure", "Test & Tune"). If the build has 8 or fewer steps, use the phase "Build" for all.
- For each step pick the single best action (place, snap, screw, slot, connect, glue, cut, test) and list only the parts handled in that step with short callout labels.

Keep prices realistic, the code complete and compilable, and write every human-readable string in the requested language.`;

export async function POST(request: Request) {
  const body = await request.json().catch(() => null);
  const idea = typeof body?.idea === 'string' ? body.idea.trim().slice(0, 500) : '';

  if (!idea) {
    return NextResponse.json({ error: 'Please describe your idea first.' }, { status: 400 });
  }

  const budget = Number.isFinite(body?.budget) ? Number(body.budget) : undefined;
  const comfortLevel = body?.comfortLevel === 'ready_to_learn' ? 'ready to learn new skills' : 'complete beginner';
  const enclosure = typeof body?.enclosurePreference === 'string' ? body.enclosurePreference.slice(0, 100) : 'any';
  const region = typeof body?.region === 'string' ? body.region.slice(0, 40) : 'US';
  const language = typeof body?.language === 'string' ? body.language.slice(0, 20) : 'en';
  const sketch =
    typeof body?.sketchImageBase64 === 'string' && body.sketchImageBase64.length < 4_000_000
      ? body.sketchImageBase64
      : undefined;

  const brief = [
    `Idea: ${idea}`,
    budget ? `Budget: about ${budget} USD total` : null,
    `Maker comfort level: ${comfortLevel}`,
    `Enclosure preference: ${enclosure}`,
    body?.hasPrinter === true
      ? '3D printer: available, so 3D printed parts are welcome where they help'
      : '3D printer: NOT available, so do not require any 3D printed parts; use cut, bought or craft alternatives',
    `Region (for part availability): ${region}`,
    `Language: ${language}`,
    sketch ? 'A rough sketch of the idea is attached.' : null,
  ]
    .filter(Boolean)
    .join('\n');

  const messages: ModelMessage[] = [
    {
      role: 'user',
      content: sketch
        ? [
            { type: 'text', text: brief },
            { type: 'file', mediaType: 'image/png', data: { type: 'data', data: sketch } },
          ]
        : brief,
    },
  ];

  try {
    const { output } = await generateText({
      model: MODEL_ID,
      system: SYSTEM_PROMPT,
      messages,
      output: Output.object({ schema: blueprintSchema }),
    });

    const stamp = Date.now();
    const toParts = (parts: z.infer<typeof partSchema>[], prefix: string) =>
      parts.map((part, index) => ({
        id: `${prefix}-${stamp}-${index}`,
        name: part.name,
        quantity: part.quantity,
        estimatedPriceUsd: part.estimatedPriceUsd,
        note: part.note ?? undefined,
      }));

    const blueprint: Blueprint = {
      id: `generated-${stamp}`,
      title: output.title,
      tagline: output.tagline,
      difficulty: output.difficulty,
      estimatedTime: output.estimatedTime,
      parts: {
        electronics: toParts(output.parts.electronics, 'el'),
        enclosureCraft: toParts(output.parts.enclosureCraft, 'ec'),
      },
      steps: output.steps.map((step, index) => ({
        ...step,
        number: index + 1,
        tip: step.tip ?? undefined,
      })),
      code: output.code,
    };

    return NextResponse.json(blueprint);
  } catch (error) {
    console.error('[generate-blueprint] AI generation failed, serving mock blueprint:', error);
    return NextResponse.json(
      buildMockBlueprint({
        idea,
        budget,
        comfortLevel: body?.comfortLevel === 'ready_to_learn' ? 'ready_to_learn' : 'beginner',
        enclosurePreference: enclosure,
      }),
      { headers: { 'X-Blueprint-Source': 'fallback' } }
    );
  }
}
