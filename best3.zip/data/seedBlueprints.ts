import type { Blueprint, ShowcaseProject } from '@/types/blueprint';

export const SEED_PET_FEEDER: Blueprint = {
  id: 'cereal-box-pet-feeder',
  title: 'Cereal Box Pet Feeder',
  tagline: 'A cardboard dispenser that drops kibble on a schedule.',
  difficulty: 'Beginner',
  estimatedTime: '2–3 hours',
  parts: {
    electronics: [
      { id: 'pf-uno', name: 'Arduino Uno (or clone)', quantity: 1, estimatedPriceUsd: 12 },
      { id: 'pf-servo', name: 'SG90 micro servo', quantity: 1, estimatedPriceUsd: 3 },
      { id: 'pf-rtc', name: 'DS3231 clock module', quantity: 1, estimatedPriceUsd: 4 },
      { id: 'pf-wires', name: 'Jumper wires (pack)', quantity: 1, estimatedPriceUsd: 3 },
    ],
    enclosureCraft: [
      { id: 'pf-box', name: 'Empty cereal box', quantity: 1, estimatedPriceUsd: 0, note: 'Recycled' },
      { id: 'pf-tape', name: 'Duct tape', quantity: 1, estimatedPriceUsd: 4 },
      { id: 'pf-straw', name: 'Wide drinking straws', quantity: 3, estimatedPriceUsd: 1 },
    ],
  },
  steps: [
    { number: 1, phase: 'Prep & Cutting', title: 'Empty and flatten the box', description: 'Empty the cereal box, open the top flaps, and wipe out any crumbs.', durationMinutes: 5, action: 'place', parts: [{ label: 'Cereal box', kind: 'container', quantity: 1 }] },
    { number: 2, phase: 'Prep & Cutting', title: 'Mark the hopper flap', description: 'Draw a 6 x 4 cm rectangle about 3 cm above the bottom on the front panel.', tip: 'Use a ruler so the gate closes evenly.', durationMinutes: 5, action: 'place', parts: [{ label: 'Front panel', kind: 'panel', quantity: 1 }] },
    { number: 3, phase: 'Prep & Cutting', title: 'Cut the hopper', description: 'Cut along three sides of the rectangle so kibble can slide out.', tip: 'Always cut away from your body and angle the cut slightly downward.', durationMinutes: 10, action: 'cut', parts: [{ label: 'Front panel', kind: 'panel', quantity: 1 }] },
    { number: 4, phase: 'Mechanism', title: 'Build the paddle', description: 'Cut a 7 x 5 cm cardboard paddle and glue it to the servo horn.', durationMinutes: 10, action: 'glue', parts: [{ label: 'Paddle', kind: 'panel', quantity: 1 }, { label: 'Servo horn', kind: 'servo', quantity: 1 }] },
    { number: 5, phase: 'Mechanism', title: 'Mount the servo gate', description: 'Tape the servo beside the flap so the paddle fully covers the opening at 0°.', durationMinutes: 15, action: 'snap', parts: [{ label: 'SG90 Servo', kind: 'servo', quantity: 1 }, { label: 'Duct tape', kind: 'tape', quantity: 1 }] },
    { number: 6, phase: 'Mechanism', title: 'Add the chute', description: 'Slot three straws under the flap to guide kibble into the bowl.', durationMinutes: 10, action: 'slot', parts: [{ label: 'Straws', kind: 'wire', quantity: 3 }] },
    { number: 7, phase: 'Wiring', title: 'Unplug and seat the board', description: 'Make sure USB is unplugged, then tape the Arduino to the side of the box.', tip: 'Never wire while the board is powered.', durationMinutes: 5, action: 'place', parts: [{ label: 'Arduino Uno', kind: 'board', quantity: 1 }] },
    { number: 8, phase: 'Wiring', title: 'Wire the servo', description: 'Connect servo signal (orange) to pin 9, red to 5V, and brown to GND.', tip: 'Brown wire is ground on most servos.', durationMinutes: 10, action: 'connect', parts: [{ label: 'Jumpers', kind: 'wire', quantity: 3 }, { label: 'SG90 Servo', kind: 'servo', quantity: 1 }] },
    { number: 9, phase: 'Wiring', title: 'Wire the clock', description: 'Connect the DS3231 SDA to A4, SCL to A5, VCC to 5V, and GND to GND.', durationMinutes: 15, action: 'connect', parts: [{ label: 'DS3231', kind: 'sensor', quantity: 1 }, { label: 'Jumpers', kind: 'wire', quantity: 4 }] },
    { number: 10, phase: 'Test & Tune', title: 'Upload and test', description: 'Upload the sketch, set a feeding time one minute away, and watch the gate open.', durationMinutes: 15, action: 'test', parts: [{ label: 'Arduino Uno', kind: 'board', quantity: 1 }] },
  ],
  code: {
    language: 'cpp',
    filename: 'pet_feeder.ino',
    source: `#include <Servo.h>

Servo gate;

void setup() {
  gate.attach(9);
  gate.write(0);
}

void loop() {
  gate.write(90);
  delay(800);
  gate.write(0);
  delay(43200000);
}`,
  },
};

export const SEED_PLANT_MONITOR: Blueprint = {
  id: 'plant-soil-monitor',
  title: 'Thirsty Plant Monitor',
  tagline: 'A tiny sensor that blinks when your plant needs water.',
  difficulty: 'Beginner',
  estimatedTime: '1–2 hours',
  parts: {
    electronics: [
      { id: 'pm-nano', name: 'Arduino Nano', quantity: 1, estimatedPriceUsd: 8 },
      { id: 'pm-sensor', name: 'Capacitive soil sensor', quantity: 1, estimatedPriceUsd: 5 },
      { id: 'pm-led', name: 'Red LED + 220Ω resistor', quantity: 1, estimatedPriceUsd: 1 },
    ],
    enclosureCraft: [
      { id: 'pm-jar', name: 'Small glass jar', quantity: 1, estimatedPriceUsd: 2 },
      { id: 'pm-glue', name: 'Hot glue sticks', quantity: 4, estimatedPriceUsd: 2 },
    ],
  },
  steps: [
    { number: 1, title: 'Seal the sensor', description: 'Add a dab of hot glue over the sensor electronics to keep them dry.', tip: 'Let the glue gun nozzle cool before touching it.', durationMinutes: 10, action: 'glue', parts: [{ label: 'Soil sensor', kind: 'sensor', quantity: 1 }] },
    { number: 2, title: 'Connect the sensor', description: 'Wire the sensor output to A0, power to 5V, and ground to GND.', durationMinutes: 15, action: 'connect', parts: [{ label: 'Arduino Nano', kind: 'board', quantity: 1 }, { label: 'Jumpers', kind: 'wire', quantity: 3 }] },
    { number: 3, title: 'Add the LED', description: 'Connect the LED through the resistor to pin 13.', durationMinutes: 10, action: 'snap', parts: [{ label: 'Red LED', kind: 'led', quantity: 1 }] },
    { number: 4, title: 'Seat it in the jar', description: 'Place the Nano in the jar lid and route the sensor into the soil.', durationMinutes: 10, action: 'slot', parts: [{ label: 'Glass jar', kind: 'container', quantity: 1 }] },
    { number: 5, title: 'Test with water', description: 'Upload the sketch, then water the plant and confirm the LED turns off.', durationMinutes: 10, action: 'test', parts: [{ label: 'Arduino Nano', kind: 'board', quantity: 1 }] },
  ],
  code: {
    language: 'cpp',
    filename: 'plant_monitor.ino',
    source: `const int threshold = 500;

void setup() {
  pinMode(13, OUTPUT);
}

void loop() {
  int moisture = analogRead(A0);
  digitalWrite(13, moisture > threshold ? HIGH : LOW);
  delay(1000);
}`,
  },
};

export const SEED_STAR_LAMP: Blueprint = {
  id: 'bedside-star-lamp',
  title: 'Bedside Star Lamp',
  tagline: 'A paper lantern that projects twinkling stars.',
  difficulty: 'Intermediate',
  estimatedTime: '3–4 hours',
  parts: {
    electronics: [
      { id: 'sl-esp', name: 'ESP32 dev board', quantity: 1, estimatedPriceUsd: 9 },
      { id: 'sl-ring', name: 'NeoPixel ring (12 LEDs)', quantity: 1, estimatedPriceUsd: 7 },
      { id: 'sl-button', name: 'Tactile push button', quantity: 1, estimatedPriceUsd: 1 },
    ],
    enclosureCraft: [
      { id: 'sl-paper', name: 'Black cardstock', quantity: 2, estimatedPriceUsd: 3 },
      { id: 'sl-pin', name: 'Push pin (for star holes)', quantity: 1, estimatedPriceUsd: 1 },
    ],
  },
  steps: [
    { number: 1, title: 'Poke the star map', description: 'Lay the cardstock flat and poke star patterns with a pin.', tip: 'Work over a folded towel to protect the table.', durationMinutes: 30, action: 'cut', parts: [{ label: 'Cardstock', kind: 'panel', quantity: 1 }] },
    { number: 2, title: 'Roll the cylinder', description: 'Roll the cardstock into a cylinder and tape the seam.', durationMinutes: 15, action: 'glue', parts: [{ label: 'Cardstock', kind: 'panel', quantity: 1 }, { label: 'Tape', kind: 'tape', quantity: 1 }] },
    { number: 3, title: 'Wire the ring', description: 'Connect NeoPixel data to GPIO 5, power to 5V, ground to GND.', durationMinutes: 20, action: 'connect', parts: [{ label: 'ESP32', kind: 'board', quantity: 1 }, { label: 'NeoPixel ring', kind: 'led', quantity: 1 }] },
    { number: 4, title: 'Add the button', description: 'Connect the button between GPIO 4 and ground to cycle colors.', durationMinutes: 15, action: 'snap', parts: [{ label: 'Push button', kind: 'button', quantity: 1 }] },
    { number: 5, title: 'Assemble', description: 'Seat the ring at the base and slide the star cylinder over it.', durationMinutes: 20, action: 'slot', parts: [{ label: 'Star cylinder', kind: 'container', quantity: 1 }] },
    { number: 6, title: 'Test the lamp', description: 'Upload the sketch, dim the room, and press the button to cycle colors.', durationMinutes: 10, action: 'test', parts: [{ label: 'ESP32', kind: 'board', quantity: 1 }] },
  ],
  code: {
    language: 'cpp',
    filename: 'star_lamp.ino',
    source: `#include <Adafruit_NeoPixel.h>

Adafruit_NeoPixel ring(12, 5, NEO_GRB + NEO_KHZ800);

void setup() {
  ring.begin();
}

void loop() {
  for (int i = 0; i < 12; i++) {
    ring.setPixelColor(i, ring.Color(random(40, 120), random(30, 90), 160));
  }
  ring.show();
  delay(400);
}`,
  },
};

export const SEED_GLOW_MASK: Blueprint = {
  id: 'glowing-led-mask',
  title: 'Glowing Costume Mask',
  tagline: 'A sound-reactive mask that lights up when you talk.',
  difficulty: 'Intermediate',
  estimatedTime: '2–3 hours',
  parts: {
    electronics: [
      { id: 'gm-gemma', name: 'Adafruit Gemma M0', quantity: 1, estimatedPriceUsd: 10 },
      { id: 'gm-mic', name: 'Electret mic amp', quantity: 1, estimatedPriceUsd: 7 },
      { id: 'gm-strip', name: 'LED strip (20cm)', quantity: 1, estimatedPriceUsd: 6 },
      { id: 'gm-battery', name: 'LiPo battery 500mAh', quantity: 1, estimatedPriceUsd: 8 },
    ],
    enclosureCraft: [
      { id: 'gm-mask', name: 'Plain craft mask', quantity: 1, estimatedPriceUsd: 4 },
      { id: 'gm-felt', name: 'Felt sheet', quantity: 1, estimatedPriceUsd: 1 },
    ],
  },
  steps: [
    { number: 1, title: 'Plan the glow', description: 'Mark where the LED strip will run along the mask edges.', durationMinutes: 15, action: 'place', parts: [{ label: 'Craft mask', kind: 'panel', quantity: 1 }] },
    { number: 2, title: 'Mount the LEDs', description: 'Glue the strip in place along your marks.', tip: 'Keep hot glue off the LED chips themselves.', durationMinutes: 20, action: 'glue', parts: [{ label: 'LED strip', kind: 'led', quantity: 1 }] },
    { number: 3, title: 'Diffuse the light', description: 'Cover the strip with felt so the glow looks soft and even.', durationMinutes: 15, action: 'glue', parts: [{ label: 'Felt sheet', kind: 'panel', quantity: 1 }] },
    { number: 4, title: 'Wire the mic', description: 'Connect mic output to A1 and LED data to D1.', durationMinutes: 25, action: 'connect', parts: [{ label: 'Gemma M0', kind: 'board', quantity: 1 }, { label: 'Mic amp', kind: 'sensor', quantity: 1 }] },
    { number: 5, title: 'Connect the battery', description: 'Plug the LiPo into the Gemma and tuck it inside the mask.', tip: 'Never puncture or bend a LiPo battery.', durationMinutes: 10, action: 'snap', parts: [{ label: 'LiPo 500mAh', kind: 'battery', quantity: 1 }] },
    { number: 6, title: 'Test the glow', description: 'Talk near the mic and check the LEDs brighten with your voice.', durationMinutes: 10, action: 'test', parts: [{ label: 'Gemma M0', kind: 'board', quantity: 1 }] },
  ],
  code: {
    language: 'cpp',
    filename: 'glow_mask.ino',
    source: `#include <Adafruit_NeoPixel.h>

Adafruit_NeoPixel strip(10, 1, NEO_GRB + NEO_KHZ800);

void setup() {
  strip.begin();
}

void loop() {
  int level = analogRead(A1);
  int brightness = map(level, 300, 700, 0, 255);
  strip.fill(strip.Color(brightness, 0, brightness / 2));
  strip.show();
}`,
  },
};

export const FEATURED_BLUEPRINTS: Blueprint[] = [
  SEED_PET_FEEDER,
  SEED_PLANT_MONITOR,
  SEED_STAR_LAMP,
  SEED_GLOW_MASK,
];

export const SEED_SHOWCASE_PROJECTS: ShowcaseProject[] = [
  {
    id: 'showcase-1',
    title: 'Two-Cat Feeder Remix',
    maker: 'Priya',
    description: 'Doubled the hopper so both cats get breakfast without fighting.',
    likes: 42,
    createdAt: '2026-09-14',
    blueprint: SEED_PET_FEEDER,
  },
  {
    id: 'showcase-2',
    title: 'Herb Garden Watcher',
    maker: 'Marco',
    description: 'Three soil sensors for basil, mint, and a stubborn rosemary.',
    likes: 31,
    createdAt: '2026-09-28',
    blueprint: SEED_PLANT_MONITOR,
  },
  {
    id: 'showcase-3',
    title: 'Aurora Night Light',
    maker: 'Jun',
    description: 'Swapped the star map for wavy cutouts and slow green fades.',
    likes: 57,
    createdAt: '2026-10-02',
    blueprint: SEED_STAR_LAMP,
  },
];
