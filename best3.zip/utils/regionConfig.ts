export type RegionCode = 'US' | 'UK' | 'EU' | 'CA' | 'AU' | 'JP';

interface RegionInfo {
  code: RegionCode;
  label: string;
  currency: string;
  locale: string;
  usdRate: number;
}

export const REGIONS: RegionInfo[] = [
  { code: 'US', label: 'United States', currency: 'USD', locale: 'en-US', usdRate: 1 },
  { code: 'UK', label: 'United Kingdom', currency: 'GBP', locale: 'en-GB', usdRate: 0.79 },
  { code: 'EU', label: 'Europe', currency: 'EUR', locale: 'de-DE', usdRate: 0.92 },
  { code: 'CA', label: 'Canada', currency: 'CAD', locale: 'en-CA', usdRate: 1.36 },
  { code: 'AU', label: 'Australia', currency: 'AUD', locale: 'en-AU', usdRate: 1.52 },
  { code: 'JP', label: 'Japan', currency: 'JPY', locale: 'ja-JP', usdRate: 151 },
];

export function getRegion(code: RegionCode): RegionInfo {
  return REGIONS.find((region) => region.code === code) ?? REGIONS[0];
}

export function formatPrice(usd: number, code: RegionCode): string {
  const region = getRegion(code);
  return new Intl.NumberFormat(region.locale, {
    style: 'currency',
    currency: region.currency,
    maximumFractionDigits: region.currency === 'JPY' ? 0 : 2,
  }).format(usd * region.usdRate);
}
