'use client';

import { useEffect } from 'react';
import { Printer, X } from 'lucide-react';
import type { Blueprint } from '@/types/blueprint';
import type { RegionCode } from '@/utils/regionConfig';
import { formatPrice } from '@/utils/regionConfig';

interface PrintBlueprintModalProps {
  blueprint: Blueprint;
  userName: string;
  selectedRegion: RegionCode;
  onClose: () => void;
}

export function PrintBlueprintModal({ blueprint, userName, selectedRegion, onClose }: PrintBlueprintModalProps) {
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [onClose]);

  const allParts = [...blueprint.parts.electronics, ...blueprint.parts.enclosureCraft];

  return (
    <div className="animate-backdrop-in fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4" onClick={onClose}>
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="print-title"
        onClick={(e) => e.stopPropagation()}
        className="animate-modal-in flex max-h-[90vh] w-full max-w-2xl flex-col overflow-hidden rounded-2xl bg-surface shadow-xl"
      >
        <div className="flex items-center justify-between border-b border-line px-5 py-3">
          <h2 id="print-title" className="font-bold">
            Print blueprint
          </h2>
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => window.print()}
              className="flex cursor-pointer items-center gap-1.5 rounded-lg bg-stone-900 px-3 py-1.5 text-sm font-semibold text-paper hover:bg-stone-700"
            >
              <Printer className="size-4" aria-hidden="true" />
              Print
            </button>
            <button
              type="button"
              onClick={onClose}
              aria-label="Close"
              className="flex size-8 cursor-pointer items-center justify-center rounded-lg hover:bg-sunken"
            >
              <X className="size-4" aria-hidden="true" />
            </button>
          </div>
        </div>
        <article className="overflow-y-auto p-6 font-sans-modern text-base text-stone-900">
          <h3 className="text-2xl font-bold">{blueprint.title}</h3>
          <p className="text-stone-600">
            {blueprint.tagline} {userName && `— built by ${userName}`}
          </p>
          <h4 className="mt-6 border-b border-stone-300 pb-1 font-bold">Parts</h4>
          <ul className="mt-2 flex flex-col gap-1">
            {allParts.map((part) => (
              <li key={part.id} className="flex justify-between gap-4">
                <span>
                  ☐ {part.name} × {part.quantity}
                </span>
                <span className="font-mono">{formatPrice(part.estimatedPriceUsd * part.quantity, selectedRegion)}</span>
              </li>
            ))}
          </ul>
          <h4 className="mt-6 border-b border-stone-300 pb-1 font-bold">Steps</h4>
          <ol className="mt-2 flex list-decimal flex-col gap-2 pl-5">
            {blueprint.steps.map((step) => (
              <li key={step.number}>
                <strong>{step.title}.</strong> {step.description}
              </li>
            ))}
          </ol>
        </article>
      </div>
    </div>
  );
}
