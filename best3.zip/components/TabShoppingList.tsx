import { Check } from 'lucide-react';
import type { Blueprint, Part } from '@/types/blueprint';
import type { RegionCode } from '@/utils/regionConfig';
import { formatPrice } from '@/utils/regionConfig';
import type { Translation } from '@/utils/i18n';

interface TabShoppingListProps {
  blueprint: Blueprint;
  checkedPartIds: string[];
  selectedRegion: RegionCode;
  t: Translation;
  onTogglePart: (id: string) => void;
  onCheckAll: (category?: 'electronics' | 'craft') => void;
}

export function TabShoppingList({
  blueprint,
  checkedPartIds,
  selectedRegion,
  t,
  onTogglePart,
  onCheckAll,
}: TabShoppingListProps) {
  const groups: { key: 'electronics' | 'craft'; label: string; parts: Part[] }[] = [
    { key: 'electronics', label: t.electronics, parts: blueprint.parts.electronics },
    { key: 'craft', label: t.craft, parts: blueprint.parts.enclosureCraft },
  ];

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      {groups.map((group) => (
        <section key={group.key} className="rounded-2xl border border-line bg-surface">
          <div className="flex items-center justify-between border-b border-line px-5 py-3">
            <h3 className="font-bold">{group.label}</h3>
            <button
              type="button"
              onClick={() => onCheckAll(group.key)}
              className="cursor-pointer text-sm font-semibold text-stone-500 hover:text-stone-900"
            >
              {t.checkAll}
            </button>
          </div>
          <ul className="divide-y divide-line">
            {group.parts.map((part) => {
              const checked = checkedPartIds.includes(part.id);
              return (
                <li key={part.id}>
                  <label className="flex cursor-pointer items-center gap-3 px-5 py-3 transition-colors hover:bg-paper">
                    <input
                      type="checkbox"
                      checked={checked}
                      onChange={() => onTogglePart(part.id)}
                      className="peer sr-only"
                    />
                    <span
                      className="flex size-5 shrink-0 items-center justify-center rounded border-2 border-stone-300 transition-colors peer-focus-visible:ring-2 peer-focus-visible:ring-stone-400"
                      style={checked ? { backgroundColor: 'var(--phenom-accent)', borderColor: 'var(--phenom-accent)' } : undefined}
                      aria-hidden="true"
                    >
                      {checked && <Check className="size-3.5 text-white" strokeWidth={3} />}
                    </span>
                    <span className={`flex-1 ${checked ? 'text-stone-400 line-through' : ''}`}>
                      {part.name}
                      {part.quantity > 1 && <span className="text-stone-400"> × {part.quantity}</span>}
                      {part.note && <span className="ml-2 text-xs text-stone-400">({part.note})</span>}
                    </span>
                    <span className="font-mono text-sm text-stone-500">
                      {formatPrice(part.estimatedPriceUsd * part.quantity, selectedRegion)}
                    </span>
                  </label>
                </li>
              );
            })}
          </ul>
        </section>
      ))}
    </div>
  );
}
