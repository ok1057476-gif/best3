import { Bookmark, Heart, Repeat2, Share2 } from 'lucide-react';
import type { Blueprint, ShowcaseProject } from '@/types/blueprint';
import type { Translation } from '@/utils/i18n';

interface TabShowcaseProps {
  projects: ShowcaseProject[];
  savedProjectIds: string[];
  t: Translation;
  onToggleBookmark: (id: string) => void;
  onAddProject: (project: ShowcaseProject) => void;
  onRemixBlueprint: (blueprint: Blueprint) => void;
  currentBlueprint: Blueprint;
  userName: string;
}

export function TabShowcase({
  projects,
  savedProjectIds,
  t,
  onToggleBookmark,
  onAddProject,
  onRemixBlueprint,
  currentBlueprint,
  userName,
}: TabShowcaseProps) {
  const alreadyShared = projects.some((p) => p.blueprint.id === currentBlueprint.id && p.maker === (userName || 'Maker'));

  const handleShare = () => {
    onAddProject({
      id: `showcase-${Date.now()}`,
      title: currentBlueprint.title,
      maker: userName || 'Maker',
      description: currentBlueprint.tagline,
      likes: 0,
      createdAt: new Date().toISOString().slice(0, 10),
      blueprint: currentBlueprint,
    });
  };

  return (
    <div className="flex flex-col gap-4">
      <div className="flex justify-end">
        <button
          type="button"
          onClick={handleShare}
          disabled={alreadyShared}
          className="flex cursor-pointer items-center gap-1.5 rounded-lg bg-stone-900 px-3 py-2 text-sm font-semibold text-paper hover:bg-stone-700 disabled:cursor-not-allowed disabled:opacity-50"
        >
          <Share2 className="size-4" aria-hidden="true" />
          {t.shareBuild}
        </button>
      </div>
      <ul className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {projects.map((project) => {
          const isSaved = savedProjectIds.includes(project.id);
          return (
            <li key={project.id} className="flex flex-col gap-3 rounded-2xl border border-line bg-surface p-5">
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <h3 className="font-bold leading-snug">{project.title}</h3>
                  <p className="text-sm text-stone-500">by {project.maker}</p>
                </div>
                <button
                  type="button"
                  onClick={() => onToggleBookmark(project.id)}
                  aria-pressed={isSaved}
                  aria-label={`Bookmark ${project.title}`}
                  className="flex size-8 shrink-0 cursor-pointer items-center justify-center rounded-lg hover:bg-sunken"
                >
                  <Bookmark
                    className="size-4"
                    aria-hidden="true"
                    style={isSaved ? { fill: 'var(--phenom-accent)', color: 'var(--phenom-accent)' } : undefined}
                  />
                </button>
              </div>
              <p className="text-pretty text-stone-600">{project.description}</p>
              <div className="mt-auto flex items-center justify-between border-t border-line pt-3 text-sm">
                <span className="flex items-center gap-1.5 text-stone-500">
                  <Heart className="size-3.5" aria-hidden="true" />
                  {project.likes}
                </span>
                <button
                  type="button"
                  onClick={() => onRemixBlueprint(project.blueprint)}
                  className="flex cursor-pointer items-center gap-1.5 rounded-lg border border-line px-2.5 py-1.5 font-semibold hover:bg-sunken"
                >
                  <Repeat2 className="size-4" aria-hidden="true" />
                  {t.remix}
                </button>
              </div>
            </li>
          );
        })}
      </ul>
    </div>
  );
}
