'use client';

import { useEffect, useRef, useState, type RefObject } from 'react';
import { createPortal } from 'react-dom';
import { Check, Eraser, Maximize2, Pencil, Slash, Trash2, Undo2 } from 'lucide-react';
import type { Translation } from '@/utils/i18n';

interface CanvasSize {
  width: number;
  height: number;
}

const DESKTOP_CANVAS: CanvasSize = { width: 1280, height: 800 };
// Portrait on phones so the fullscreen editor can use the height instead of a thin 8:5 strip.
const MOBILE_CANVAS: CanvasSize = { width: 600, height: 1000 };
const COMPACT_STROKE_CSS_PX = 2.5;
const MAX_UNDO_STEPS = 12;
const INK = '#1c1917';
const COLORS = [INK, '#2563eb', '#dc2626', '#16a34a'];
const DOT_BACKGROUND =
  '[background-image:radial-gradient(#E5E1D8_1px,transparent_1px)] [background-size:16px_16px]';

type Tool = 'pen' | 'line' | 'eraser';

interface StrokeStyle {
  tool: Tool;
  color: string;
  width: number;
}

interface StrokeState extends StrokeStyle {
  start: { x: number; y: number };
  last: { x: number; y: number };
  snapshot: ImageData | null;
}

interface StrokeOptions {
  getStyle: (canvas: HTMLCanvasElement, rect: DOMRect) => StrokeStyle;
  onStart?: (ctx: CanvasRenderingContext2D) => void;
  onInk?: () => void;
}

function canvasHasInk(canvas: HTMLCanvasElement) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return false;
  const { data } = ctx.getImageData(0, 0, canvas.width, canvas.height);
  for (let i = 3; i < data.length; i += 4) {
    if (data[i] !== 0) return true;
  }
  return false;
}

function createStrokeHandlers(stroke: RefObject<StrokeState | null>, options: StrokeOptions) {
  const pointFrom = (e: React.PointerEvent<HTMLCanvasElement>) => {
    const canvas = e.currentTarget;
    const rect = canvas.getBoundingClientRect();
    return {
      x: ((e.clientX - rect.left) / rect.width) * canvas.width,
      y: ((e.clientY - rect.top) / rect.height) * canvas.height,
    };
  };

  const applyStyle = (ctx: CanvasRenderingContext2D, style: StrokeStyle) => {
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';
    ctx.lineWidth = style.width;
    ctx.strokeStyle = style.color;
    ctx.globalCompositeOperation = style.tool === 'eraser' ? 'destination-out' : 'source-over';
  };

  return {
    onPointerDown(e: React.PointerEvent<HTMLCanvasElement>) {
      const canvas = e.currentTarget;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      canvas.setPointerCapture(e.pointerId);
      options.onStart?.(ctx);

      const style = options.getStyle(canvas, canvas.getBoundingClientRect());
      const point = pointFrom(e);
      stroke.current = {
        ...style,
        start: point,
        last: point,
        snapshot: style.tool === 'line' ? ctx.getImageData(0, 0, canvas.width, canvas.height) : null,
      };

      if (style.tool !== 'line') {
        applyStyle(ctx, style);
        ctx.beginPath();
        ctx.moveTo(point.x, point.y);
        ctx.lineTo(point.x + 0.01, point.y);
        ctx.stroke();
        if (style.tool === 'pen') options.onInk?.();
      }
    },

    onPointerMove(e: React.PointerEvent<HTMLCanvasElement>) {
      const active = stroke.current;
      if (!active) return;
      const ctx = e.currentTarget.getContext('2d');
      if (!ctx) return;
      const point = pointFrom(e);
      applyStyle(ctx, active);

      if (active.tool === 'line' && active.snapshot) {
        ctx.putImageData(active.snapshot, 0, 0);
        ctx.beginPath();
        ctx.moveTo(active.start.x, active.start.y);
        ctx.lineTo(point.x, point.y);
        ctx.stroke();
        options.onInk?.();
      } else {
        ctx.beginPath();
        ctx.moveTo(active.last.x, active.last.y);
        ctx.lineTo(point.x, point.y);
        ctx.stroke();
        if (active.tool === 'pen') options.onInk?.();
      }
      active.last = point;
    },

    onPointerUp() {
      stroke.current = null;
    },

    onPointerCancel() {
      stroke.current = null;
    },
  };
}

interface SketchPadProps {
  t: Translation;
  canvasRef: RefObject<HTMLCanvasElement | null>;
  hasSketch: boolean;
  onHasSketchChange: (hasSketch: boolean) => void;
}

export function SketchPad({ t, canvasRef, hasSketch, onHasSketchChange }: SketchPadProps) {
  const [expanded, setExpanded] = useState(false);
  const [size, setSize] = useState<CanvasSize>(DESKTOP_CANVAS);
  const compactStroke = useRef<StrokeState | null>(null);

  useEffect(() => {
    if (window.matchMedia('(max-width: 767px)').matches) setSize(MOBILE_CANVAS);
  }, []);

  const clearCompact = () => {
    const canvas = canvasRef.current;
    canvas?.getContext('2d')?.clearRect(0, 0, canvas.width, canvas.height);
    onHasSketchChange(false);
  };

  const compactHandlers = createStrokeHandlers(compactStroke, {
    getStyle: (canvas, rect) => ({
      tool: 'pen',
      color: INK,
      width: COMPACT_STROKE_CSS_PX * (canvas.width / rect.width),
    }),
    onInk: () => {
      if (!hasSketch) onHasSketchChange(true);
    },
  });

  const commitFromExpanded = (source: HTMLCanvasElement) => {
    const target = canvasRef.current;
    const ctx = target?.getContext('2d');
    if (target && ctx) {
      ctx.clearRect(0, 0, target.width, target.height);
      ctx.drawImage(source, 0, 0);
    }
    onHasSketchChange(canvasHasInk(source));
    setExpanded(false);
  };

  return (
    <div className="flex h-full min-h-0 w-full flex-col rounded-xl border border-line bg-surface">
      <div className="flex min-h-10 items-center justify-between gap-2 border-b border-line px-3">
        <span className="text-sm font-semibold">{t.sketchLabel}</span>
        <div className="flex items-center gap-2">
          {hasSketch && (
            <button
              type="button"
              onClick={clearCompact}
              className="flex min-h-12 cursor-pointer items-center px-1 text-sm text-stone-500 underline-offset-2 hover:text-stone-900 hover:underline md:min-h-0 md:px-0"
            >
              {t.clearSketch}
            </button>
          )}
          <button
            type="button"
            onClick={() => setExpanded(true)}
            aria-label={t.expandSketch}
            title={t.expandSketch}
            className="flex size-12 cursor-pointer items-center justify-center rounded-md text-stone-500 md:size-7 transition-colors hover:bg-sunken hover:text-stone-900 focus-visible:outline-2 focus-visible:outline-offset-2"
          >
            <Maximize2 className="size-3.5" aria-hidden="true" />
          </button>
        </div>
      </div>

      <div
        className={`relative m-2 flex aspect-[4/3] items-center justify-center overflow-hidden rounded-lg bg-[#FDFBF7] [container-type:size] md:aspect-auto md:min-h-48 md:flex-1 ${DOT_BACKGROUND}`}
      >
        <canvas
          ref={canvasRef}
          width={size.width}
          height={size.height}
          {...compactHandlers}
          aria-label={t.sketchLabel}
          style={{
            aspectRatio: `${size.width} / ${size.height}`,
            width: `min(100cqw, calc(100cqh * ${size.width / size.height}))`,
          }}
          className="touch-none cursor-crosshair"
        />
        {!hasSketch && (
          <p className="pointer-events-none absolute inset-x-0 bottom-2 text-center text-xs text-stone-400">
            {t.sketchHint}
          </p>
        )}
      </div>

      {expanded &&
        createPortal(
          <SketchStudio t={t} size={size} source={canvasRef.current} onDone={commitFromExpanded} />,
          document.body,
        )}
    </div>
  );
}

interface SketchStudioProps {
  t: Translation;
  size: CanvasSize;
  source: HTMLCanvasElement | null;
  onDone: (canvas: HTMLCanvasElement) => void;
}

function SketchStudio({ t, size: canvasSize, source, onDone }: SketchStudioProps) {
  const dialogRef = useRef<HTMLDialogElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const stroke = useRef<StrokeState | null>(null);
  const history = useRef<ImageData[]>([]);
  const [canUndo, setCanUndo] = useState(false);
  const [tool, setTool] = useState<Tool>('pen');
  const [color, setColor] = useState(INK);
  const [size, setSize] = useState(6);

  useEffect(() => {
    const dialog = dialogRef.current;
    if (dialog && !dialog.open) dialog.showModal();
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (canvas && ctx) {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      if (source) ctx.drawImage(source, 0, 0);
    }
  }, [source]);

  const finish = () => {
    if (canvasRef.current) onDone(canvasRef.current);
  };

  const pushHistory = (ctx: CanvasRenderingContext2D) => {
    history.current.push(ctx.getImageData(0, 0, canvasSize.width, canvasSize.height));
    if (history.current.length > MAX_UNDO_STEPS) history.current.shift();
    setCanUndo(true);
  };

  const undo = () => {
    const previous = history.current.pop();
    const ctx = canvasRef.current?.getContext('2d');
    if (previous && ctx) ctx.putImageData(previous, 0, 0);
    setCanUndo(history.current.length > 0);
  };

  const clearAll = () => {
    const canvas = canvasRef.current;
    const ctx = canvas?.getContext('2d');
    if (!canvas || !ctx) return;
    pushHistory(ctx);
    ctx.clearRect(0, 0, canvas.width, canvas.height);
  };

  const handlers = createStrokeHandlers(stroke, {
    getStyle: () => ({ tool, color, width: tool === 'eraser' ? size * 2.5 : size }),
    onStart: pushHistory,
  });

  const tools: { id: Tool; label: string; icon: typeof Pencil }[] = [
    { id: 'pen', label: t.toolPen, icon: Pencil },
    { id: 'line', label: t.toolLine, icon: Slash },
    { id: 'eraser', label: t.toolEraser, icon: Eraser },
  ];

  const previewSize = Math.min(32, tool === 'eraser' ? size * 2.5 : size);

  return (
    <dialog
      ref={dialogRef}
      aria-label={t.sketchLabel}
      onCancel={(e) => {
        e.preventDefault();
        finish();
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) finish();
      }}
      onKeyDown={(e) => {
        if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z') {
          e.preventDefault();
          undo();
        }
      }}
      className="m-0 h-dvh max-h-none w-dvw max-w-none overflow-x-hidden overflow-y-auto rounded-none border-0 bg-surface p-0 text-stone-900 shadow-2xl backdrop:bg-black/60 md:m-auto md:h-fit md:w-[min(96vw,1100px)] md:overflow-hidden md:rounded-2xl md:border md:border-line"
    >
      <div className="flex h-full flex-col md:h-auto">
        <header className="flex items-center justify-end border-b border-line px-3 py-1.5 md:justify-between md:px-4 md:py-3">
          <h2 className="sr-only text-base font-semibold md:not-sr-only">{t.sketchLabel}</h2>
          <button
            type="button"
            onClick={finish}
            autoFocus
            className="flex min-h-11 cursor-pointer items-center gap-1.5 rounded-lg px-3 text-sm font-semibold text-white transition-opacity hover:opacity-90 md:min-h-0 md:px-4 md:py-2"
            style={{ backgroundColor: 'var(--phenom-accent)' }}
          >
            <Check className="size-4" aria-hidden="true" />
            {t.done}
          </button>
        </header>

        <div className="relative order-3 flex shrink-0 items-center gap-3 overflow-x-auto border-t border-line bg-paper px-3 pb-[max(0.375rem,env(safe-area-inset-bottom))] pt-1.5 [scrollbar-width:none] md:order-2 md:flex-wrap md:gap-x-5 md:gap-y-3 md:overflow-visible md:border-b md:border-t-0 md:px-4 md:py-2.5 md:pb-2.5 md:pt-2.5">
          <div role="group" aria-label={t.sketchTools} className="flex shrink-0 rounded-lg border border-line bg-sunken p-0.5">
            {tools.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                type="button"
                aria-pressed={tool === id}
                aria-label={label}
                title={label}
                onClick={() => setTool(id)}
                className={`flex size-11 cursor-pointer items-center justify-center rounded-md transition-colors md:size-8 ${
                  tool === id ? 'bg-surface shadow-sm' : 'text-stone-500 hover:text-stone-900'
                }`}
              >
                <Icon className="size-4" aria-hidden="true" />
              </button>
            ))}
          </div>

          <div role="group" aria-label={t.sketchColor} className="flex shrink-0 items-center md:gap-1">
            {COLORS.map((swatch) => {
              const selected = color === swatch && tool !== 'eraser';
              return (
                <button
                  key={swatch}
                  type="button"
                  aria-pressed={color === swatch}
                  aria-label={swatch}
                  onClick={() => {
                    setColor(swatch);
                    if (tool === 'eraser') setTool('pen');
                  }}
                  className="flex size-11 cursor-pointer items-center justify-center md:size-8"
                >
                  <span
                    className={`size-6 rounded-full border-2 transition-transform ${
                      selected ? 'scale-110 border-stone-400' : 'border-surface shadow-[0_0_0_1px_var(--color-line)]'
                    }`}
                    style={{ backgroundColor: swatch }}
                  />
                </button>
              );
            })}
          </div>

          <div className="flex shrink-0 items-center gap-2.5">
            <label htmlFor="brush-size" className="sr-only text-sm font-medium md:not-sr-only">
              {t.brushSize}
            </label>
            <input
              id="brush-size"
              type="range"
              min={2}
              max={40}
              value={size}
              onChange={(e) => setSize(Number(e.target.value))}
              className="h-11 w-28 cursor-pointer md:h-auto md:w-36"
              style={{ accentColor: 'var(--phenom-accent)' }}
            />
            <span className="hidden size-8 items-center justify-center md:flex" aria-hidden="true">
              <span
                className="rounded-full"
                style={{
                  width: previewSize,
                  height: previewSize,
                  backgroundColor: tool === 'eraser' ? '#d6d3d1' : color,
                }}
              />
            </span>
            <span className="hidden w-6 text-sm tabular-nums text-stone-500 md:block">{size}</span>
          </div>

          <div className="flex shrink-0 items-center gap-1 md:ml-auto">
            <button
              type="button"
              onClick={undo}
              disabled={!canUndo}
              className="flex size-11 cursor-pointer items-center justify-center gap-1.5 rounded-lg text-sm text-stone-600 transition-colors hover:bg-sunken hover:text-stone-900 disabled:cursor-not-allowed disabled:opacity-40 md:size-auto md:px-2.5 md:py-1.5"
            >
              <Undo2 className="size-4" aria-hidden="true" />
              <span className="sr-only md:not-sr-only">{t.undo}</span>
            </button>
            <button
              type="button"
              onClick={clearAll}
              className="flex size-11 cursor-pointer items-center justify-center gap-1.5 rounded-lg text-sm text-stone-600 transition-colors hover:bg-sunken hover:text-stone-900 md:size-auto md:px-2.5 md:py-1.5"
            >
              <Trash2 className="size-4" aria-hidden="true" />
              <span className="sr-only md:not-sr-only">{t.clearSketch}</span>
            </button>
          </div>
        </div>

        <div className="order-2 flex min-h-[350px] min-w-0 flex-1 items-center justify-center bg-sunken p-2 md:order-3 md:min-h-0 md:flex-none md:p-4">
          <canvas
            ref={canvasRef}
            width={canvasSize.width}
            height={canvasSize.height}
            {...handlers}
            aria-label={t.sketchLabel}
            style={
              {
                aspectRatio: `${canvasSize.width} / ${canvasSize.height}`,
                '--ratio': canvasSize.height / canvasSize.width,
              } as React.CSSProperties
            }
            className={`max-h-full max-w-full touch-none cursor-crosshair rounded-lg border border-line bg-[#FDFBF7] shadow-sm md:max-h-none md:max-w-none md:h-[min(calc(100dvh_-_15rem),calc((min(96vw,1100px)_-_2rem)*var(--ratio)))] ${DOT_BACKGROUND}`}
          />
        </div>
      </div>
    </dialog>
  );
}
