'use client';

import { useEffect, useState } from 'react';
import { Moon, Palette, Sun, X } from 'lucide-react';
import { getAccentTheme } from '@/types/theme';
import type { ThemePreference } from '@/types/theme';
import type { RegionCode } from '@/utils/regionConfig';
import { REGIONS } from '@/utils/regionConfig';
import type { LanguageCode } from '@/utils/i18n';
import { LANGUAGES, getTranslation } from '@/utils/i18n';

type FontPreference = 'sans' | 'handwriting';

interface Preferences {
  name: string;
  region: RegionCode;
  accentId: string;
  language: LanguageCode;
  font: FontPreference;
  hasPrinter: boolean;
  theme: ThemePreference;
}

interface OnboardingModalProps {
  initialTheme: ThemePreference;
  initialHasPrinter: boolean;
  initialName: string;
  initialRegion: RegionCode;
  initialAccent: string;
  initialLanguage: LanguageCode;
  initialFont: FontPreference;
  isSettingsMode: boolean;
  onSave: (data: Preferences) => void;
  onLiveChange: (changes: Partial<Preferences>) => void;
  onClose: () => void;
}

export function OnboardingModal({
  initialTheme,
  initialHasPrinter,
  initialName,
  initialRegion,
  initialAccent,
  initialLanguage,
  initialFont,
  isSettingsMode,
  onSave,
  onLiveChange,
  onClose,
}: OnboardingModalProps) {
  const [name, setName] = useState(initialName);
  const [region, setRegion] = useState(initialRegion);
  const [accentId, setAccentId] = useState(initialAccent);
  const [language, setLanguage] = useState(initialLanguage);
  const [font, setFont] = useState(initialFont);
  const [hasPrinter, setHasPrinter] = useState(initialHasPrinter);
  const [theme, setTheme] = useState(initialTheme);

  const t = getTranslation(language);
  const accent = getAccentTheme(accentId);

  useEffect(() => {
    if (!isSettingsMode) return;
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose();
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [isSettingsMode, onClose]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave({ name, region, accentId, language, font, hasPrinter, theme });
  };

  const fieldLabel = 'text-sm font-semibold';
  const fieldInput = 'h-12 w-full rounded-lg border border-line bg-paper px-3 py-2 font-sans-modern text-base outline-none focus:border-stone-400 md:h-auto';

  return (
    <div
      className="animate-backdrop-in fixed inset-0 z-50 flex items-center justify-center bg-black/50 p-4"
      onClick={isSettingsMode ? onClose : undefined}
    >
      <form
        role="dialog"
        aria-modal="true"
        aria-labelledby="onboarding-title"
        onClick={(e) => e.stopPropagation()}
        onSubmit={handleSubmit}
        className="animate-modal-in relative flex w-full max-w-md flex-col gap-5 rounded-2xl bg-surface p-6 font-sans-modern text-base text-stone-900 shadow-xl"
      >
        {isSettingsMode && (
          <button
            type="button"
            onClick={onClose}
            aria-label={t.close}
            className="absolute right-2 top-2 flex size-12 cursor-pointer md:right-4 md:top-4 md:size-8 items-center justify-center rounded-lg text-stone-500 hover:bg-sunken hover:text-stone-900"
          >
            <X className="size-4" aria-hidden="true" />
          </button>
        )}

        <h2 id="onboarding-title" className="pr-8 text-xl font-bold tracking-tight">
          {isSettingsMode ? t.settingsTitle : t.welcomeTitle}
        </h2>

        <div className="flex flex-col gap-1.5">
          <label htmlFor="pref-name" className={fieldLabel}>
            {t.yourName}
          </label>
          <input
            id="pref-name"
            value={name}
            autoComplete="given-name"
            onChange={(e) => {
              setName(e.target.value);
              onLiveChange({ name: e.target.value });
            }}
            placeholder="Maker"
            className={fieldInput}
          />
        </div>

        <div className="grid grid-cols-2 gap-3">
          <div className="flex flex-col gap-1.5">
            <label htmlFor="pref-region" className={fieldLabel}>
              {t.region}
            </label>
            <select
              id="pref-region"
              value={region}
              onChange={(e) => {
                const value = e.target.value as RegionCode;
                setRegion(value);
                onLiveChange({ region: value });
              }}
              className={`${fieldInput} cursor-pointer`}
            >
              {REGIONS.map((r) => (
                <option key={r.code} value={r.code}>
                  {r.label}
                </option>
              ))}
            </select>
          </div>
          <div className="flex flex-col gap-1.5">
            <label htmlFor="pref-language" className={fieldLabel}>
              {t.language}
            </label>
            <select
              id="pref-language"
              value={language}
              onChange={(e) => {
                const value = e.target.value as LanguageCode;
                setLanguage(value);
                onLiveChange({ language: value });
              }}
              className={`${fieldInput} cursor-pointer`}
            >
              {LANGUAGES.map((l) => (
                <option key={l.code} value={l.code}>
                  {l.label}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="flex items-center justify-between gap-3">
          <label htmlFor="pref-accent" className={fieldLabel}>
            {t.accent}
          </label>
          <div className="flex items-center gap-3">
            <span className="font-mono text-sm uppercase text-stone-500">{accent.hex}</span>
            <input
              id="pref-accent"
              type="color"
              value={accent.hex}
              onChange={(e) => {
                setAccentId(e.target.value);
                onLiveChange({ accentId: e.target.value });
              }}
              className="size-12 cursor-pointer appearance-none rounded-full border border-line bg-transparent p-0.5 md:size-9 [&::-moz-color-swatch]:rounded-full [&::-moz-color-swatch]:border-0 [&::-webkit-color-swatch-wrapper]:p-0 [&::-webkit-color-swatch]:rounded-full [&::-webkit-color-swatch]:border-0"
            />
          </div>
        </div>

        {isSettingsMode && (
          <fieldset className="flex flex-col gap-2">
            <legend className={`${fieldLabel} mb-2`}>{t.theme}</legend>
            <div className="grid grid-cols-3 gap-2">
              {(
                [
                  { value: 'light', label: t.themeLight, Icon: Sun },
                  { value: 'dark', label: t.themeDark, Icon: Moon },
                  { value: 'accent', label: t.themeAccent, Icon: Palette },
                ] as const
              ).map(({ value, label, Icon }) => (
                <button
                  key={value}
                  type="button"
                  aria-pressed={theme === value}
                  onClick={() => {
                    setTheme(value);
                    onLiveChange({ theme: value });
                  }}
                  className={`flex min-h-12 cursor-pointer items-center justify-center gap-1.5 rounded-lg border px-2 py-2.5 text-sm transition-colors md:min-h-0 ${
                    theme === value ? 'border-stone-900 bg-sunken font-semibold' : 'border-line hover:bg-paper'
                  }`}
                >
                  <Icon className="size-4 shrink-0" aria-hidden="true" />
                  {label}
                </button>
              ))}
            </div>
          </fieldset>
        )}

        {isSettingsMode && (
          <fieldset className="flex flex-col gap-2">
            <legend className={`${fieldLabel} mb-2`}>{t.font}</legend>
            <div className="grid grid-cols-2 gap-2">
              {(['sans', 'handwriting'] as const).map((option) => (
                <button
                  key={option}
                  type="button"
                  aria-pressed={font === option}
                  onClick={() => {
                    setFont(option);
                    onLiveChange({ font: option });
                  }}
                  className={`min-h-12 cursor-pointer rounded-lg border px-3 py-2.5 transition-colors md:min-h-0 ${
                    font === option ? 'border-stone-900 bg-sunken' : 'border-line hover:bg-paper'
                  } ${option === 'handwriting' ? 'font-handwriting text-lg' : 'font-sans-modern'}`}
                >
                  {option === 'handwriting' ? t.handwriting : t.sans}
                </button>
              ))}
            </div>
          </fieldset>
        )}

        <fieldset className="flex flex-col gap-2">
          <legend className={`${fieldLabel} mb-2`}>{t.printer}</legend>
          <div className="grid grid-cols-2 gap-2">
            {([false, true] as const).map((available) => (
              <button
                key={String(available)}
                type="button"
                aria-pressed={hasPrinter === available}
                onClick={() => {
                  setHasPrinter(available);
                  onLiveChange({ hasPrinter: available });
                }}
                className={`min-h-12 cursor-pointer rounded-lg border px-3 py-2.5 text-sm transition-colors md:min-h-0 ${
                  hasPrinter === available ? 'border-stone-900 bg-sunken font-semibold' : 'border-line hover:bg-paper'
                }`}
              >
                {available ? t.hasPrinter : t.noPrinter}
              </button>
            ))}
          </div>
        </fieldset>

        <button
          type="submit"
          className="min-h-12 cursor-pointer rounded-xl px-5 py-3 font-semibold text-white transition-opacity hover:opacity-90 md:min-h-0"
          style={{ backgroundColor: accent.hex }}
        >
          {isSettingsMode ? t.save : t.start}
        </button>
      </form>
    </div>
  );
}
