import { useEffect, useMemo, useRef, useState } from 'react';
import { CheckCircle2, ChevronLeft, ChevronRight, Circle, Clock, LifeBuoy, Lock } from 'lucide-react';
import type { Blueprint, BuildStep } from '@/types/blueprint';
import type { Translation } from '@/utils/i18n';
import { groupStepsIntoPhases } from '@/lib/step-phases';
import { layoutAssembly } from '@/lib/iso';
import { IsoStepDiagram } from '@/components/iso/IsoStepDiagram';
import { IsoAssemblyThumb } from '@/components/iso/IsoAssemblyThumb';
import { PartsTray } from '@/components/iso/PartsTray';

interface TabStepGuideProps {
  blueprint: Blueprint;
  cardDensity: number;
  completedStepNumbers: number[];
  t: Translation;
  onToggleStepComplete: (stepNumber: number) => void;
  onOpenStuckHelp: (step: BuildStep) => void;
}

export function TabStepGuide({ blueprint, completedStepNumbers, t, onToggleStepComplete, onOpenStuckHelp }: TabStepGuideProps) {
  const steps = blueprint.steps;
  const activeStepIndex = steps.findIndex((step) => !completedStepNumbers.includes(step.number));
  const followKey = `${blueprint.id}:${activeStepIndex}`;
  const [pageIndex, setPageIndex] = useState(activeStepIndex === -1 ? steps.length - 1 : activeStepIndex);
  const [trackedKey, setTrackedKey] = useState(followKey);
  if (trackedKey !== followKey) {
    setTrackedKey(followKey);
    setPageIndex(activeStepIndex === -1 ? steps.length - 1 : activeStepIndex);
  }

  const markDoneRef = useRef<HTMLButtonElement>(null);
  const shouldFocusMarkDone = useRef(false);
  useEffect(() => {
    if (!shouldFocusMarkDone.current) return;
    shouldFocusMarkDone.current = false;
    markDoneRef.current?.focus();
  }, [activeStepIndex]);

  const phases = useMemo(() => groupStepsIntoPhases(steps), [steps]);
  const placementsByStep = useMemo(() => layoutAssembly(steps), [steps]);
  const allPlacements = useMemo(() => steps.flatMap((step) => placementsByStep.get(step.number) ?? []), [steps, placementsByStep]);

  if (steps.length === 0) return null;

  const page = Math.min(Math.max(pageIndex, 0), steps.length - 1);
  const step = steps[page];
  const isDone = completedStepNumbers.includes(step.number);
  const isActive = page === activeStepIndex;
  const isLocked = !isDone && !isActive;
  const activeStep = steps[activeStepIndex];
  const ghosts = steps.slice(0, page).flatMap((previous) => placementsByStep.get(previous.number) ?? []);
  const phaseIndex = phases.findIndex((phase) => phase.steps.includes(step));
  const phase = phases[phaseIndex];
  const showPhase = phases.length > 1 || Boolean(phase?.name);

  const handleMarkDone = () => {
    shouldFocusMarkDone.current = true;
    onToggleStepComplete(step.number);
  };

  return (
    <section aria-label={`${blueprint.title} instruction booklet`} className="overflow-hidden rounded-2xl border border-line bg-surface">
      <header className="flex items-start justify-between gap-4 border-b border-line p-4 sm:p-5">
        <div className="flex min-w-0 flex-col gap-1.5">
          <p className="font-mono text-xs font-bold uppercase tracking-wider text-stone-500">
            Page {page + 1} of {steps.length}
            {showPhase && phase && (
              <>
                {' · '}Phase {phaseIndex + 1}
                {phase.name ? ` · ${phase.name}` : ''}
              </>
            )}
          </p>
          <h2 className={`text-balance text-xl font-bold leading-tight sm:text-2xl ${isDone ? 'text-stone-400' : ''}`}>
            <span className="sr-only">Step {step.number}: </span>
            {step.title}
          </h2>
          <div className="flex flex-wrap items-center gap-2 text-sm">
            {isDone ? (
              <span className="inline-flex items-center gap-1 rounded-full bg-emerald-50 px-2 py-0.5 font-semibold text-emerald-700">
                <CheckCircle2 className="size-3.5" aria-hidden="true" />
                {t.done}
              </span>
            ) : isActive ? (
              <span className="inline-flex items-center gap-1 rounded-full bg-[var(--phenom-accent)]/10 px-2 py-0.5 font-semibold text-[var(--phenom-accent)]">
                <Circle className="size-3.5" aria-hidden="true" />
                Current step
              </span>
            ) : (
              <span className="inline-flex items-center gap-1 rounded-full bg-stone-100 px-2 py-0.5 font-semibold text-stone-500">
                <Lock className="size-3.5" aria-hidden="true" />
                Locked
              </span>
            )}
            <span className="inline-flex items-center gap-1 text-stone-500">
              <Clock className="size-3.5" aria-hidden="true" />
              {step.durationMinutes} min
            </span>
          </div>
        </div>
        <IsoAssemblyThumb placements={allPlacements} title={blueprint.title} />
      </header>

      <div className="flex flex-col gap-4 p-4 sm:p-5 md:flex-row">
        <PartsTray parts={step.parts ?? []} />
        <div className="flex min-w-0 flex-1 flex-col gap-4">
          <IsoStepDiagram
            stepNumber={step.number}
            action={step.action ?? 'place'}
            active={placementsByStep.get(step.number) ?? []}
            ghosts={ghosts}
            dimmed={isLocked}
          />
          <div className="flex flex-col gap-2">
            <p className="text-pretty leading-relaxed text-stone-700">{step.description}</p>
            {step.tip && <p className="rounded-lg bg-sunken px-3 py-2 text-sm text-stone-700">Tip: {step.tip}</p>}
          </div>
          <div className="flex flex-wrap items-center justify-end gap-2 border-t border-line pt-3 text-sm">
            {isLocked && activeStep && (
              <p className="mr-auto flex items-center gap-1.5 text-stone-500">
                <Lock className="size-3.5" aria-hidden="true" />
                Finish step {activeStep.number} first.
                <button
                  type="button"
                  onClick={() => setPageIndex(activeStepIndex)}
                  className="cursor-pointer font-semibold text-[var(--phenom-accent)] underline-offset-2 hover:underline"
                >
                  Go to current step
                </button>
              </p>
            )}
            <button
              type="button"
              onClick={() => onOpenStuckHelp(step)}
              disabled={!isActive}
              className="flex items-center gap-1.5 rounded-lg px-3 py-2 font-semibold text-stone-600 enabled:cursor-pointer enabled:hover:bg-sunken enabled:hover:text-stone-900 disabled:cursor-not-allowed disabled:opacity-40"
            >
              <LifeBuoy className="size-4" aria-hidden="true" />
              {t.stuck}
            </button>
            <button
              ref={isActive ? markDoneRef : undefined}
              type="button"
              onClick={handleMarkDone}
              disabled={!isActive}
              aria-pressed={isDone}
              className="flex items-center gap-1.5 rounded-lg px-3 py-2 font-semibold text-white enabled:cursor-pointer enabled:hover:opacity-90 disabled:cursor-not-allowed disabled:bg-stone-300"
              style={isActive ? { backgroundColor: 'var(--phenom-accent)' } : undefined}
            >
              {isDone ? <CheckCircle2 className="size-4" aria-hidden="true" /> : isLocked ? <Lock className="size-4" aria-hidden="true" /> : <Circle className="size-4" aria-hidden="true" />}
              {isDone ? t.done : t.markDone}
            </button>
          </div>
        </div>
      </div>

      <nav aria-label="Booklet pages" className="flex items-center gap-3 border-t border-line bg-paper px-4 py-3 sm:px-5">
        <button
          type="button"
          onClick={() => setPageIndex(page - 1)}
          disabled={page === 0}
          className="flex items-center gap-1 rounded-lg border border-line bg-surface px-3 py-2 text-sm font-semibold enabled:cursor-pointer enabled:hover:bg-sunken disabled:cursor-not-allowed disabled:opacity-40"
        >
          <ChevronLeft className="size-4" aria-hidden="true" />
          Previous
        </button>
        <div className="flex min-w-0 flex-1 flex-col items-center gap-1.5">
          <span className="font-mono text-xs font-bold text-stone-600" aria-live="polite">
            Page {page + 1} of {steps.length}
          </span>
          <ol className="flex w-full max-w-md gap-1">
            {steps.map((pageStep, index) => {
              const done = completedStepNumbers.includes(pageStep.number);
              const current = index === activeStepIndex;
              return (
                <li key={pageStep.number} className="flex-1">
                  <button
                    type="button"
                    onClick={() => setPageIndex(index)}
                    aria-label={`Go to page ${index + 1}: ${pageStep.title}${done ? ' (done)' : current ? ' (current)' : ''}`}
                    aria-current={index === page ? 'page' : undefined}
                    className={`block h-1.5 w-full cursor-pointer rounded-full transition-colors ${
                      index === page ? 'ring-2 ring-offset-1 ring-stone-800' : ''
                    } ${done ? 'bg-emerald-500' : current ? 'bg-[var(--phenom-accent)]' : 'bg-stone-200 hover:bg-stone-300'}`}
                  />
                </li>
              );
            })}
          </ol>
        </div>
        <button
          type="button"
          onClick={() => setPageIndex(page + 1)}
          disabled={page === steps.length - 1}
          className="flex items-center gap-1 rounded-lg border border-line bg-surface px-3 py-2 text-sm font-semibold enabled:cursor-pointer enabled:hover:bg-sunken disabled:cursor-not-allowed disabled:opacity-40"
        >
          Next
          <ChevronRight className="size-4" aria-hidden="true" />
        </button>
      </nav>
    </section>
  );
}
