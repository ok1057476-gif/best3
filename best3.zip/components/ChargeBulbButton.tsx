'use client';

import { useEffect, useRef, useState, type CSSProperties } from 'react';
import { Lightbulb } from 'lucide-react';

const MAX_HOLD_MS = 5000;
const MIN_BURST = 0.15;

interface ChargeBulbButtonProps {
  accentHex: string;
}

export function ChargeBulbButton({ accentHex }: ChargeBulbButtonProps) {
  const bodyRef = useRef<HTMLSpanElement>(null);
  const frameRef = useRef<number | null>(null);
  const holdStartRef = useRef<number | null>(null);
  const chargeRef = useRef(0);
  const [isCharging, setIsCharging] = useState(false);
  const [burst, setBurst] = useState({ id: 0, strength: 0 });

  useEffect(() => {
    return () => {
      if (frameRef.current !== null) cancelAnimationFrame(frameRef.current);
    };
  }, []);

  const writeCharge = (value: number) => {
    chargeRef.current = value;
    bodyRef.current?.style.setProperty('--charge', value.toFixed(3));
  };

  const tick = (now: number) => {
    if (holdStartRef.current === null) return;
    const progress = Math.min((now - holdStartRef.current) / MAX_HOLD_MS, 1);
    writeCharge(1 - (1 - progress) * (1 - progress));
    frameRef.current = requestAnimationFrame(tick);
  };

  const startCharge = () => {
    if (holdStartRef.current !== null) return;
    holdStartRef.current = performance.now();
    setIsCharging(true);
    frameRef.current = requestAnimationFrame(tick);
  };

  const releaseCharge = () => {
    if (holdStartRef.current === null) return;
    holdStartRef.current = null;
    if (frameRef.current !== null) cancelAnimationFrame(frameRef.current);
    frameRef.current = null;

    const strength = Math.max(chargeRef.current, MIN_BURST);
    setIsCharging(false);
    setBurst((previous) => ({ id: previous.id + 1, strength }));
    writeCharge(0);
    navigator.vibrate?.(Math.round(8 + strength * 32));
  };

  return (
    <button
      type="button"
      aria-label="Hold to charge the idea bulb"
      onPointerDown={(event) => {
        if (event.button !== 0) return;
        event.currentTarget.setPointerCapture(event.pointerId);
        startCharge();
      }}
      onPointerUp={releaseCharge}
      onPointerCancel={releaseCharge}
      onLostPointerCapture={releaseCharge}
      onKeyDown={(event) => {
        if ((event.key === ' ' || event.key === 'Enter') && !event.repeat) {
          event.preventDefault();
          startCharge();
        }
      }}
      onKeyUp={(event) => {
        if (event.key === ' ' || event.key === 'Enter') releaseCharge();
      }}
      onBlur={releaseCharge}
      onContextMenu={(event) => event.preventDefault()}
      className="relative size-11 shrink-0 cursor-pointer touch-none select-none rounded-lg outline-none [-webkit-touch-callout:none] focus-visible:ring-2 focus-visible:ring-stone-900 focus-visible:ring-offset-2"
    >
      <span
        ref={bodyRef}
        className={`bulb-body relative flex size-full items-center justify-center rounded-lg text-white ${
          isCharging ? 'bulb-charging' : ''
        }`}
        style={{ backgroundColor: accentHex }}
      >
        {burst.id > 0 && (
          <span
            key={burst.id}
            className="pointer-events-none absolute inset-0"
            style={{ '--burst': burst.strength } as CSSProperties}
            aria-hidden="true"
          >
            <span className="bulb-burst-flash absolute inset-0 rounded-lg bg-yellow-200 opacity-0" />
            <span
              className="bulb-burst-ring absolute inset-0 rounded-lg opacity-0"
              style={{ boxShadow: '0 0 0 2px rgba(253, 224, 71, 0.95), 0 0 14px rgba(253, 224, 71, 0.65)' }}
            />
          </span>
        )}
        <Lightbulb className="bulb-icon relative size-6" aria-hidden="true" />
      </span>
    </button>
  );
}
