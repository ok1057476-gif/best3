'use client';

import { Moon, Plus, Printer, Settings, Sun } from 'lucide-react';
import { ChargeBulbButton } from '@/components/ChargeBulbButton';
import type { AccentTheme, ResolvedTheme } from '@/types/theme';
import type { Translation } from '@/utils/i18n';

interface HeaderProps {
  accentTheme: AccentTheme;
  t: Translation;
  resolvedTheme: ResolvedTheme;
  onToggleTheme: () => void;
  onOpenSettings: () => void;
  onOpenPrint: () => void;
  onResetToNew: () => void;
  hasBlueprint: boolean;
}

export function Header({
  accentTheme,
  t,
  resolvedTheme,
  onToggleTheme,
  onOpenSettings,
  onOpenPrint,
  onResetToNew,
  hasBlueprint,
}: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 w-full border-b border-line bg-paper/90 backdrop-blur">
      <div className="mx-auto flex h-16 w-full max-w-7xl items-center justify-between gap-3 px-4 sm:px-6 lg:px-8">
        <div className="flex min-w-0 items-center gap-3.5 sm:gap-4">
          <ChargeBulbButton accentHex={accentTheme.hex} />
          <span className="flex min-w-0 flex-col text-sm leading-tight font-extrabold tracking-tight sm:text-base md:flex-row md:gap-1.5 md:text-2xl md:leading-normal">
  <span>{t.appName.split(' ')[0]}</span>{' '}
  <span>{t.appName.split(' ').slice(1).join(' ')}</span>
  </span>
        </div>

        <nav className="flex items-center gap-2" aria-label="Workbench actions">
          <button
            type="button"
            onClick={onResetToNew}
            className="flex min-h-12 min-w-12 cursor-pointer items-center justify-center gap-1.5 rounded-lg bg-stone-900 px-3 py-3 text-sm font-semibold text-paper transition-colors hover:bg-stone-700 md:min-h-0 md:min-w-0 md:py-2"
          >
            <Plus className="size-4" aria-hidden="true" />
            <span className="hidden sm:inline">{t.newIdea}</span>
            <span className="sr-only sm:hidden">{t.newIdea}</span>
          </button>
          {hasBlueprint && (
            <button
              type="button"
              onClick={onOpenPrint}
              className="flex min-h-12 min-w-12 cursor-pointer items-center justify-center gap-1.5 rounded-lg border border-line bg-surface px-3 py-3 text-sm font-semibold transition-colors hover:bg-sunken md:min-h-0 md:min-w-0 md:py-2"
            >
              <Printer className="size-4" aria-hidden="true" />
              <span className="hidden sm:inline">{t.print}</span>
              <span className="sr-only sm:hidden">{t.print}</span>
            </button>
          )}
          <button
            type="button"
            onClick={onToggleTheme}
            aria-label={resolvedTheme === 'dark' ? t.switchToLight : t.switchToDark}
            className="hidden size-9 cursor-pointer items-center justify-center rounded-lg border border-line bg-surface transition-colors hover:bg-sunken md:flex"
          >
            {resolvedTheme === 'dark' ? (
              <Sun className="size-4" aria-hidden="true" />
            ) : (
              <Moon className="size-4" aria-hidden="true" />
            )}
          </button>
          <button
            type="button"
            onClick={onOpenSettings}
            aria-label={t.settings}
            className="flex size-12 cursor-pointer items-center justify-center rounded-lg border border-line bg-surface transition-colors hover:bg-sunken md:size-9"
          >
            <Settings className="size-4" aria-hidden="true" />
          </button>
        </nav>
      </div>
    </header>
  );
}
