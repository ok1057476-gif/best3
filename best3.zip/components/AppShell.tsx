'use client';

import dynamic from 'next/dynamic';

// App reads localStorage during initial state, so it renders client-only to avoid hydration mismatches.
const App = dynamic(() => import('@/components/App'), {
  ssr: false,
  loading: () => <div className="min-h-screen blueprint-grid" />,
});

export function AppShell() {
  return <App />;
}
