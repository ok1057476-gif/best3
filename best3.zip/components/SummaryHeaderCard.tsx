import { Clock, Gauge, Wallet } from 'lucide-react';
import type { Blueprint } from '@/types/blueprint';
import type { RegionCode } from '@/utils/regionConfig';
import { formatPrice } from '@/utils/regionConfig';
import type { Translation } from '@/utils/i18n';

interface SummaryHeaderCardProps {
  blueprint: Blueprint;
  checkedCount: number;
  totalPartsCount: number;
  userName: string;
  selectedRegion: RegionCode;
  t: Translation;
}

export function SummaryHeaderCard({
  blueprint,
  checkedCount,
  totalPartsCount,
  selectedRegion,
  t,
}: SummaryHeaderCardProps) {
  const allParts = [...blueprint.parts.electronics, ...blueprint.parts.enclosureCraft];
  const totalCost = allParts.reduce((sum, p) => sum + p.estimatedPriceUsd * p.quantity, 0);
  const progress = totalPartsCount ? Math.round((checkedCount / totalPartsCount) * 100) : 0;

  return (
    <section className="mb-6 rounded-2xl border border-line bg-surface p-5 sm:p-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div className="min-w-0">
          <h2 className="text-balance text-2xl font-bold tracking-tight sm:text-3xl">{blueprint.title}</h2>
          <p className="mt-1 text-pretty text-stone-600">{blueprint.tagline}</p>
          <ul className="mt-3 flex flex-wrap gap-2 text-sm">
            <li className="flex items-center gap-1.5 rounded-md bg-sunken px-2 py-1">
              <Gauge className="size-3.5" aria-hidden="true" />
              {blueprint.difficulty}
            </li>
            <li className="flex items-center gap-1.5 rounded-md bg-sunken px-2 py-1">
              <Clock className="size-3.5" aria-hidden="true" />
              {blueprint.estimatedTime}
            </li>
            <li className="flex items-center gap-1.5 rounded-md bg-sunken px-2 py-1">
              <Wallet className="size-3.5" aria-hidden="true" />
              {t.estimatedCost} {formatPrice(totalCost, selectedRegion)}
            </li>
          </ul>
        </div>
        <div className="w-full md:w-56">
          <div className="mb-1.5 flex justify-between text-sm">
            <span className="font-semibold">
              {checkedCount}/{totalPartsCount} {t.partsReady}
            </span>
            <span className="text-stone-500">{progress}%</span>
          </div>
          <div
            className="h-2 overflow-hidden rounded-full bg-sunken"
            role="progressbar"
            aria-valuenow={progress}
            aria-valuemin={0}
            aria-valuemax={100}
            aria-label={t.partsReady}
          >
            <div
              className="h-full rounded-full transition-[width] duration-300"
              style={{ width: `${progress}%`, backgroundColor: 'var(--phenom-accent)' }}
            />
          </div>
        </div>
      </div>
    </section>
  );
}
