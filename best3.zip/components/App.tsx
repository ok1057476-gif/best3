/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

'use client';

import React, { useState, useEffect } from 'react';
import { Header } from '@/components/Header';
import { InspirationBar } from '@/components/InspirationBar';
import { SummaryHeaderCard } from '@/components/SummaryHeaderCard';
import { SetupSection } from '@/components/SetupSection';
import { TabShoppingList } from '@/components/TabShoppingList';
import { TabStepGuide } from '@/components/TabStepGuide';
import { TabTheCode } from '@/components/TabTheCode';
import { TabShowcase } from '@/components/TabShowcase';
import { AssistantChat } from '@/components/AssistantChat';
import { PrintBlueprintModal } from '@/components/PrintBlueprintModal';
import { OnboardingModal } from '@/components/OnboardingModal';

import {
  SEED_PET_FEEDER,
  SEED_PLANT_MONITOR,
  SEED_STAR_LAMP,
  SEED_GLOW_MASK,
  SEED_SHOWCASE_PROJECTS,
} from '@/data/seedBlueprints';
import { Blueprint, ShowcaseProject, BuildStep } from '@/types/blueprint';
import { RegionCode } from '@/utils/regionConfig';
import {
  DEFAULT_ACCENT_HEX,
  THEME_STORAGE_KEY,
  applyTheme,
  getAccentTheme,
  isThemePreference,
  resolveTheme,
} from '@/types/theme';
import type { ResolvedTheme, ThemePreference } from '@/types/theme';
import { LanguageCode, getTranslation } from '@/utils/i18n';
import { Package, Wrench, Code2, Sparkles } from 'lucide-react';
import { buildMockBlueprint } from '@/lib/mock-blueprint';

function isBlueprint(value: unknown): value is Blueprint {
  const candidate = value as Partial<Blueprint> | null;
  return (
    !!candidate &&
    typeof candidate.title === 'string' &&
    Array.isArray(candidate.steps) &&
    candidate.steps.length > 0 &&
    !!candidate.parts &&
    Array.isArray(candidate.parts.electronics) &&
    !!candidate.code
  );
}

const STORAGE_KEYS = {
  ONBOARDING_DONE: 'phenom_onboarding_completed_v2',
  USER_NAME: 'phenom_workbench_user_name_v2',
  REGION: 'phenom_selected_region_v2',
  LANGUAGE: 'phenom_selected_language_v2',
  ACCENT_COLOR: 'phenom_accent_color_v2',
  SAVED_PROJECTS: 'phenom_saved_project_ids_v2',
  BLUEPRINT: 'phenom_studio_blueprint_v2',
  FONT: 'phenom_studio_font_v3',
  PRINTER: 'phenom_has_3d_printer_v2',
  DENSITY: 'phenom_studio_density_v2',
  CHECKED_PARTS: 'phenom_studio_checked_parts_v2',
  COMPLETED_STEPS: 'phenom_studio_completed_steps_v2',
  SHOWCASE: 'phenom_studio_showcase_v2',
};

function readJson<T>(key: string, fallback: T): T {
  try {
    const saved = localStorage.getItem(key);
    return saved ? (JSON.parse(saved) as T) : fallback;
  } catch {
    return fallback;
  }
}

function checkHasSavedPreferences(): boolean {
  try {
    const isDone = localStorage.getItem(STORAGE_KEYS.ONBOARDING_DONE);
    const savedName = localStorage.getItem(STORAGE_KEYS.USER_NAME);
    return isDone === 'true' || (savedName !== null && savedName.trim().length > 0);
  } catch {
    return false;
  }
}

type TabId = 'shopping' | 'steps' | 'code' | 'showcase';

export default function App() {
  const [hasCompletedOnboarding, setHasCompletedOnboarding] = useState<boolean>(checkHasSavedPreferences);
  const [showSettingsModal, setShowSettingsModal] = useState(false);

  const [userName, setUserName] = useState<string>(() => localStorage.getItem(STORAGE_KEYS.USER_NAME) || '');
  const [selectedRegion, setSelectedRegion] = useState<RegionCode>(
    () => (localStorage.getItem(STORAGE_KEYS.REGION) as RegionCode) || 'US'
  );
  const [selectedLanguage, setSelectedLanguage] = useState<LanguageCode>(
    () => (localStorage.getItem(STORAGE_KEYS.LANGUAGE) as LanguageCode) || 'en'
  );
  const t = getTranslation(selectedLanguage);

  const [accentId, setAccentId] = useState<string>(() => localStorage.getItem(STORAGE_KEYS.ACCENT_COLOR) || DEFAULT_ACCENT_HEX);
  const accentTheme = getAccentTheme(accentId);

  const [savedProjectIds, setSavedProjectIds] = useState<string[]>(() =>
    readJson(STORAGE_KEYS.SAVED_PROJECTS, ['cereal-box-pet-feeder'])
  );
  const [fontPreference, setFontPreference] = useState<'sans' | 'handwriting'>(
    () => (localStorage.getItem(STORAGE_KEYS.FONT) as 'sans' | 'handwriting') || 'sans'
  );
  const [themePreference, setThemePreference] = useState<ThemePreference>(readStoredTheme);
  const [resolvedTheme, setResolvedTheme] = useState<ResolvedTheme>(() => resolveTheme(themePreference));
  const [hasPrinter, setHasPrinter] = useState<boolean>(() => localStorage.getItem(STORAGE_KEYS.PRINTER) === 'true');
  const [cardDensity] = useState<number>(() => {
    const saved = localStorage.getItem(STORAGE_KEYS.DENSITY);
    return saved ? Number(saved) : 4;
  });
  const [blueprint, setBlueprint] = useState<Blueprint>(() => readJson(STORAGE_KEYS.BLUEPRINT, SEED_PET_FEEDER));
  const [checkedPartIds, setCheckedPartIds] = useState<string[]>(() => readJson(STORAGE_KEYS.CHECKED_PARTS, []));
  const [completedStepNumbers, setCompletedStepNumbers] = useState<number[]>(() =>
    readJson(STORAGE_KEYS.COMPLETED_STEPS, [])
  );
  const [showcaseProjects, setShowcaseProjects] = useState<ShowcaseProject[]>(() =>
    readJson(STORAGE_KEYS.SHOWCASE, SEED_SHOWCASE_PROJECTS)
  );

  const [activeTab, setActiveTab] = useState<TabId>('shopping');
  const [isGenerating, setIsGenerating] = useState(false);
  const [showPrintModal, setShowPrintModal] = useState(false);
  const [showNewSetup, setShowNewSetup] = useState(true);
  const [stuckStep, setStuckStep] = useState<BuildStep | null>(null);

  useEffect(() => {
    if (hasCompletedOnboarding) localStorage.setItem(STORAGE_KEYS.ONBOARDING_DONE, 'true');
  }, [hasCompletedOnboarding]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.USER_NAME, userName);
  }, [userName]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.REGION, selectedRegion);
  }, [selectedRegion]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.LANGUAGE, selectedLanguage);
  }, [selectedLanguage]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.ACCENT_COLOR, accentId);
    document.documentElement.style.setProperty('--phenom-accent', accentTheme.hex);
  }, [accentId, accentTheme]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SAVED_PROJECTS, JSON.stringify(savedProjectIds));
  }, [savedProjectIds]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.FONT, fontPreference);
  }, [fontPreference]);

  useEffect(() => {
    localStorage.setItem(THEME_STORAGE_KEY, themePreference);
    setResolvedTheme(resolveTheme(themePreference));
    applyTheme(themePreference);
  }, [themePreference]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.PRINTER, String(hasPrinter));
  }, [hasPrinter]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.DENSITY, String(cardDensity));
  }, [cardDensity]);

  useEffect(() => {
    if (blueprint) localStorage.setItem(STORAGE_KEYS.BLUEPRINT, JSON.stringify(blueprint));
  }, [blueprint]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.CHECKED_PARTS, JSON.stringify(checkedPartIds));
  }, [checkedPartIds]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.COMPLETED_STEPS, JSON.stringify(completedStepNumbers));
  }, [completedStepNumbers]);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEYS.SHOWCASE, JSON.stringify(showcaseProjects));
  }, [showcaseProjects]);

  const handleLivePreferenceChange = (changes: {
    name?: string;
    region?: RegionCode;
    accentId?: string;
    language?: LanguageCode;
    font?: 'sans' | 'handwriting';
    hasPrinter?: boolean;
    theme?: ThemePreference;
  }) => {
    if (changes.theme !== undefined) setThemePreference(changes.theme);
    if (changes.name !== undefined) setUserName(changes.name);
    if (changes.region !== undefined) setSelectedRegion(changes.region);
    if (changes.accentId !== undefined) {
      setAccentId(changes.accentId);
      document.documentElement.style.setProperty('--phenom-accent', getAccentTheme(changes.accentId).hex);
    }
    if (changes.language !== undefined) setSelectedLanguage(changes.language);
    if (changes.font !== undefined) setFontPreference(changes.font);
    if (changes.hasPrinter !== undefined) setHasPrinter(changes.hasPrinter);
  };

  const handleCompleteOnboarding = (data: {
    name: string;
    region: RegionCode;
    accentId: string;
    language: LanguageCode;
    font: 'sans' | 'handwriting';
    hasPrinter: boolean;
    theme: ThemePreference;
  }) => {
    setThemePreference(data.theme);
    setHasPrinter(data.hasPrinter);
    setUserName(data.name.trim() || 'Maker');
    setSelectedRegion(data.region);
    setAccentId(data.accentId);
    setSelectedLanguage(data.language);
    setFontPreference(data.font);
    setHasCompletedOnboarding(true);
    setShowSettingsModal(false);
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  };

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'instant' });
  }, []);

  const handleToggleBookmark = (projectId: string) => {
    setSavedProjectIds((prev) =>
      prev.includes(projectId) ? prev.filter((id) => id !== projectId) : [...prev, projectId]
    );
  };

  const handleTogglePart = (partId: string) => {
    setCheckedPartIds((prev) => (prev.includes(partId) ? prev.filter((id) => id !== partId) : [...prev, partId]));
  };

  const handleCheckAll = (category?: 'electronics' | 'craft') => {
    if (!blueprint) return;
    let targetIds: string[];
    if (category === 'electronics') {
      targetIds = blueprint.parts.electronics.map((p) => p.id);
    } else if (category === 'craft') {
      targetIds = blueprint.parts.enclosureCraft.map((p) => p.id);
    } else {
      targetIds = [...blueprint.parts.electronics, ...blueprint.parts.enclosureCraft].map((p) => p.id);
    }

    const allAreChecked = targetIds.every((id) => checkedPartIds.includes(id));
    setCheckedPartIds((prev) =>
      allAreChecked ? prev.filter((id) => !targetIds.includes(id)) : Array.from(new Set([...prev, ...targetIds]))
    );
  };

  const handleToggleStepComplete = (stepNumber: number) => {
    setCompletedStepNumbers((prev) => {
      const activeStep = blueprint.steps.find((step) => !prev.includes(step.number));
      if (!activeStep || activeStep.number !== stepNumber) return prev;
      return [...prev, stepNumber];
    });
  };

  const handleGenerateBlueprint = async (params: {
    idea: string;
    sketchImageBase64?: string;
    sketchImageMimeType?: string;
    budget: number;
    comfortLevel: 'beginner' | 'ready_to_learn';
    enclosurePreference: string;
    hasPrinter: boolean;
  }) => {
    setIsGenerating(true);
    let newBlueprint: Blueprint;
    try {
      const response = await fetch('/api/generate-blueprint', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          ...params,
          region: selectedRegion,
          userName: userName || undefined,
          language: selectedLanguage,
        }),
      });
      const data = await response.json().catch(() => null);
      if (!response.ok || !isBlueprint(data)) throw new Error('Invalid blueprint response');
      newBlueprint = data;
    } catch (err) {
      console.warn('[generate-blueprint] falling back to local mock blueprint:', err);
      newBlueprint = buildMockBlueprint(params);
    }

    setBlueprint(newBlueprint);
    setCheckedPartIds([]);
    setCompletedStepNumbers([]);
    setShowNewSetup(false);
    setActiveTab('steps');
    setIsGenerating(false);
  };

  const handleSelectFeaturedProject = (sampleId: string) => {
    let chosen = SEED_PET_FEEDER;
    if (sampleId === 'plant-soil-monitor') chosen = SEED_PLANT_MONITOR;
    if (sampleId === 'bedside-star-lamp') chosen = SEED_STAR_LAMP;
    if (sampleId === 'glowing-led-mask') chosen = SEED_GLOW_MASK;

    setBlueprint(chosen);
    setCheckedPartIds([]);
    setCompletedStepNumbers([]);
    setActiveTab('steps');
  };

  const handleRemixBlueprint = (remixedBlueprint: Blueprint) => {
    setBlueprint({ ...remixedBlueprint, id: `remix-${Date.now()}` });
    setCheckedPartIds([]);
    setCompletedStepNumbers([]);
    setActiveTab('steps');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleAddCommunityProject = (project: ShowcaseProject) => {
    setShowcaseProjects((prev) => [project, ...prev]);
  };

  const handleOpenStuckHelp = (step: BuildStep) => {
    setStuckStep(step);
    document.getElementById('assistant-chat-container')?.scrollIntoView({ behavior: 'smooth' });
  };

  const allParts = blueprint ? [...blueprint.parts.electronics, ...blueprint.parts.enclosureCraft] : [];

  const tabs: { id: TabId; label: string; icon: React.ElementType; badge?: React.ReactNode }[] = [
    { id: 'shopping', label: t.tabShopping, icon: Package, badge: allParts.length },
    { id: 'steps', label: t.tabSteps, icon: Wrench, badge: `${blueprint.steps.length} Steps` },
    { id: 'code', label: t.tabCode, icon: Code2 },
    {
      id: 'showcase',
      label: t.tabShowcase,
      icon: Sparkles,
      badge: savedProjectIds.length > 0 ? `${savedProjectIds.length} ${t.saved}` : undefined,
    },
  ];

  return (
    <div
      className={`flex min-h-screen w-full flex-col items-stretch justify-start blueprint-grid text-stone-900 ${
        fontPreference === 'handwriting' ? 'font-handwriting text-xl leading-relaxed sm:text-2xl' : 'font-sans-modern'
      }`}
    >
      <Header
        accentTheme={accentTheme}
        t={t}
        resolvedTheme={resolvedTheme}
        onToggleTheme={() => setThemePreference(resolvedTheme === 'dark' ? 'light' : 'dark')}
        onOpenSettings={() => setShowSettingsModal(true)}
        onOpenPrint={() => setShowPrintModal(true)}
        onResetToNew={() => {
          setShowNewSetup(true);
          window.scrollTo({ top: 0, behavior: 'smooth' });
        }}
        hasBlueprint={Boolean(blueprint)}
      />

      <main className="mx-auto w-full max-w-7xl flex-1 px-4 py-6 sm:px-6 sm:py-8 lg:px-8">
        {showNewSetup && (
          <SetupSection
            defaultHasPrinter={hasPrinter}
            userName={userName}
            onUpdateUserName={setUserName}
            selectedRegion={selectedRegion}
            t={t}
            onGenerate={handleGenerateBlueprint}
            isLoading={isGenerating}
            isCollapsible={Boolean(blueprint)}
            onClose={() => setShowNewSetup(false)}
          />
        )}

        <InspirationBar
          activeBlueprintId={blueprint?.id}
          savedProjectIds={savedProjectIds}
          t={t}
          onToggleBookmark={handleToggleBookmark}
          onSelectProject={handleSelectFeaturedProject}
          onOpenShowcaseTab={() => setActiveTab('showcase')}
        />

        {blueprint && (
          <>
            <SummaryHeaderCard
              blueprint={blueprint}
              checkedCount={checkedPartIds.length}
              totalPartsCount={allParts.length}
              userName={userName}
              selectedRegion={selectedRegion}
              t={t}
            />

            <div className="mb-6 border-b border-line">
              <nav className="flex gap-2 overflow-x-auto pb-px sm:gap-4" aria-label="Tabs">
                {tabs.map(({ id, label, icon: Icon, badge }) => (
                  <button
                    key={id}
                    type="button"
                    onClick={() => setActiveTab(id)}
                    aria-current={activeTab === id ? 'page' : undefined}
                    className={`flex min-h-12 cursor-pointer items-center gap-2 whitespace-nowrap border-b-2 px-3 py-3 font-sans-modern md:min-h-0 text-xs font-bold transition-colors sm:px-4 sm:text-sm ${
                      activeTab === id
                        ? 'border-stone-900 text-stone-900'
                        : 'border-transparent text-stone-500 hover:border-stone-300 hover:text-stone-800'
                    }`}
                  >
                    <Icon className="size-4" aria-hidden="true" />
                    <span>{label}</span>
                    {badge !== undefined && (
                      <span
                        className={`rounded px-1.5 text-[11px] ${
                          id === 'showcase'
                            ? 'bg-stone-900 font-mono text-paper'
                            : 'border border-line bg-sunken'
                        }`}
                      >
                        {badge}
                      </span>
                    )}
                  </button>
                ))}
              </nav>
            </div>

            <div className="min-h-[400px]">
              {activeTab === 'shopping' && (
                <TabShoppingList
                  blueprint={blueprint}
                  checkedPartIds={checkedPartIds}
                  selectedRegion={selectedRegion}
                  t={t}
                  onTogglePart={handleTogglePart}
                  onCheckAll={handleCheckAll}
                />
              )}

              {activeTab === 'steps' && (
                <TabStepGuide
                  blueprint={blueprint}
                  cardDensity={cardDensity}
                  completedStepNumbers={completedStepNumbers}
                  t={t}
                  onToggleStepComplete={handleToggleStepComplete}
                  onOpenStuckHelp={handleOpenStuckHelp}
                />
              )}

              {activeTab === 'code' && <TabTheCode blueprint={blueprint} t={t} />}

              {activeTab === 'showcase' && (
                <TabShowcase
                  projects={showcaseProjects}
                  savedProjectIds={savedProjectIds}
                  t={t}
                  onToggleBookmark={handleToggleBookmark}
                  onAddProject={handleAddCommunityProject}
                  onRemixBlueprint={handleRemixBlueprint}
                  currentBlueprint={blueprint}
                  userName={userName}
                />
              )}
            </div>

            <div id="assistant-chat-container">
              <AssistantChat
                key={blueprint.id}
                blueprint={blueprint}
                checkedPartIds={checkedPartIds}
                userName={userName}
                activeStep={stuckStep}
                t={t}
                onClearActiveStep={() => setStuckStep(null)}
                onUpdateBlueprint={(updated) => setBlueprint(updated)}
              />
            </div>
          </>
        )}
      </main>

      {showPrintModal && blueprint && (
        <PrintBlueprintModal
          blueprint={blueprint}
          userName={userName}
          selectedRegion={selectedRegion}
          onClose={() => setShowPrintModal(false)}
        />
      )}

      {(!hasCompletedOnboarding || showSettingsModal) && (
        <OnboardingModal
          initialHasPrinter={hasPrinter}
          initialName={userName}
          initialRegion={selectedRegion}
          initialAccent={accentId}
          initialLanguage={selectedLanguage}
          initialFont={fontPreference}
          initialTheme={themePreference}
          isSettingsMode={hasCompletedOnboarding}
          onSave={handleCompleteOnboarding}
          onLiveChange={handleLivePreferenceChange}
          onClose={() => setShowSettingsModal(false)}
        />
      )}
    </div>
  );
}
