import { COS30, toPoints } from '@/lib/iso';

const GRID_STEP = 16;

export function IsoGridDefs({ id }: { id: string }) {
  const w = GRID_STEP * 2 * COS30;
  const h = GRID_STEP;
  return (
    <defs>
      <linearGradient id={`${id}-paper`} x1="0" y1="0" x2="1" y2="1">
        <stop offset="0" stopColor="#F4F8FC" />
        <stop offset="1" stopColor="#E3ECF5" />
      </linearGradient>
      <pattern id={`${id}-grid`} width={w} height={h} patternUnits="userSpaceOnUse">
        <path d={`M0 0 L${w} ${h} M${w} 0 L0 ${h}`} fill="none" stroke="#C9D7E6" strokeWidth={0.6} />
      </pattern>
      <filter id={`${id}-blur`} x="-50%" y="-50%" width="200%" height="200%">
        <feGaussianBlur stdDeviation={4} />
      </filter>
    </defs>
  );
}

export function IsoPlatform({ id }: { id: string }) {
  const x0 = -80;
  const x1 = 80;
  const y0 = -60;
  const y1 = 60;
  const z0 = -6;
  const z1 = 0;
  return (
    <g stroke="#94A3B8" strokeWidth={1} strokeLinejoin="round">
      <polygon
        points={toPoints([[x0, y1, z0], [x1, y1, z0], [x1, y0, z0], [x1, y0, z0]])}
        fill="#0F172A"
        opacity={0.08}
        stroke="none"
        filter={`url(#${id}-blur)`}
      />
      <polygon points={toPoints([[x0, y1, z0], [x1, y1, z0], [x1, y1, z1], [x0, y1, z1]])} fill="#D9E2EC" />
      <polygon points={toPoints([[x1, y0, z0], [x1, y1, z0], [x1, y1, z1], [x1, y0, z1]])} fill="#C3CFDC" />
      <polygon points={toPoints([[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]])} fill="#F7FAFD" />
    </g>
  );
}
