import { useId } from 'react';
import type { StepAction } from '@/types/blueprint';
import {
  PART_FOOTPRINT,
  PART_HEIGHT,
  byDepth,
  isoEllipse,
  partCallout,
  project,
  toPoints,
  type Placement,
  type Vec3,
} from '@/lib/iso';
import { ANODIZED_ORANGE, IsoPart } from '@/components/iso/IsoPart';
import { IsoGridDefs, IsoPlatform } from '@/components/iso/IsoScene';

const INK = '#1E293B';
const AXIS = '#7C93B0';
const ARROW = ANODIZED_ORANGE;
const VIEW = { x: -200, y: -180, w: 400, h: 265 };

const ACTION_LABEL: Record<StepAction, string> = {
  place: 'PLACE',
  snap: 'SNAP IN',
  screw: 'SCREW IN',
  slot: 'SLOT IN',
  connect: 'CONNECT',
  glue: 'GLUE',
  cut: 'CUT',
  test: 'TEST',
};

function liftFor(action: StepAction) {
  return action === 'cut' || action === 'test' ? 0 : 50;
}

function Footprint({ placement }: { placement: Placement }) {
  const [w, d] = PART_FOOTPRINT[placement.part.kind];
  const { x, y, z } = placement;
  return (
    <polygon
      points={toPoints([
        [x - w / 2, y - d / 2, z],
        [x + w / 2, y - d / 2, z],
        [x + w / 2, y + d / 2, z],
        [x - w / 2, y + d / 2, z],
      ])}
      fill="#FFFFFF"
      fillOpacity={0.55}
      stroke={AXIS}
      strokeWidth={1}
      strokeDasharray="4 3"
    />
  );
}

function DimensionLine({ from, to, offset }: { from: Vec3; to: Vec3; offset: Vec3 }) {
  const a = project([from[0] + offset[0], from[1] + offset[1], from[2]]);
  const b = project([to[0] + offset[0], to[1] + offset[1], to[2]]);
  const ticks = [from, to].map((point) => {
    const start = project(point);
    const end = project([point[0] + offset[0] * 1.3, point[1] + offset[1] * 1.3, point[2]]);
    return `M${start[0]} ${start[1]} L${end[0]} ${end[1]}`;
  });
  return (
    <g stroke={AXIS} strokeWidth={0.8} fill="none" opacity={0.8}>
      <path d={ticks.join(' ')} strokeDasharray="2 2" />
      <path d={`M${a[0]} ${a[1]} L${b[0]} ${b[1]}`} />
      {[a, b].map(([px, py], index) => (
        <circle key={index} cx={px} cy={py} r={1.6} fill={AXIS} stroke="none" />
      ))}
    </g>
  );
}

function MotionArrow({ placement, lift, action, markerId }: { placement: Placement; lift: number; action: StepAction; markerId: string }) {
  const [w, d] = PART_FOOTPRINT[placement.part.kind];
  const h = PART_HEIGHT[placement.part.kind];
  const { x, y, z } = placement;
  const corner: [number, number] = [x + w / 2 + 6, y + d / 2 + 6];

  if (action === 'connect') {
    const [sx, sy] = project([corner[0], corner[1], z + lift + h / 2]);
    const [ex, ey] = project([x, y, z + 2]);
    return (
      <path
        d={`M${sx} ${sy} Q${sx + 40} ${(sy + ey) / 2}, ${ex + 8} ${ey}`}
        fill="none"
        stroke={ARROW}
        strokeWidth={2.4}
        strokeDasharray="6 4"
        strokeLinecap="round"
        markerEnd={`url(#${markerId})`}
      />
    );
  }

  if (action === 'cut') {
    const a = project([x - w / 2 - 10, y + d / 2 + 6, z + h + 1]);
    const b = project([x + w / 2 + 10, y - d / 2 - 6, z + h + 1]);
    return (
      <path d={`M${a[0]} ${a[1]} L${b[0]} ${b[1]}`} stroke={ARROW} strokeWidth={2.4} strokeDasharray="7 4" strokeLinecap="round" />
    );
  }

  if (action === 'test') {
    const [bx, by] = project([x, y, z + h + 14]);
    return (
      <path
        d={`M${bx + 2} ${by - 14} L${bx - 7} ${by + 2} H${bx} L${bx - 3} ${by + 14} L${bx + 7} ${by - 3} H${bx} Z`}
        fill="#FACC15"
        stroke={INK}
        strokeWidth={1.4}
        strokeLinejoin="round"
      />
    );
  }

  const [sx, sy] = project([corner[0], corner[1], z + lift + h * 0.6]);
  const [, ey] = project([corner[0], corner[1], z + 4]);
  const drop = (
    <g>
      <path d={`M${sx} ${sy} L${sx} ${ey}`} stroke="#FFFFFF" strokeWidth={5} strokeLinecap="round" />
      <path d={`M${sx} ${sy} L${sx} ${ey}`} stroke={ARROW} strokeWidth={2.4} strokeLinecap="round" markerEnd={`url(#${markerId})`} />
    </g>
  );

  if (action === 'screw') {
    const [cx, cy] = project([x, y, z + lift + h + 8]);
    const { rx, ry } = isoEllipse(Math.min(w, 22) / 2 + 6);
    return (
      <g>
        {drop}
        <path
          d={`M${cx - rx} ${cy} A${rx} ${ry} 0 1 0 ${cx} ${cy - ry}`}
          fill="none"
          stroke={ARROW}
          strokeWidth={2.4}
          strokeLinecap="round"
          markerEnd={`url(#${markerId})`}
        />
      </g>
    );
  }

  if (action === 'snap') {
    const [tx, ty] = project([x - w / 2, y + d / 2, z + 2]);
    return (
      <g>
        {drop}
        <path d={`M${tx - 6} ${ty - 6} l-6 -5 M${tx - 8} ${ty + 2} h-8 M${tx - 6} ${ty + 9} l-6 5`} stroke={ARROW} strokeWidth={2} strokeLinecap="round" />
      </g>
    );
  }

  if (action === 'glue') {
    const [gx, gy] = project([x, y, z + 1]);
    return (
      <g>
        {drop}
        <path
          d={`M${gx} ${gy - 12} C${gx + 6} ${gy - 4}, ${gx + 7} ${gy + 3}, ${gx} ${gy + 4} C${gx - 7} ${gy + 3}, ${gx - 6} ${gy - 4}, ${gx} ${gy - 12} Z`}
          fill="#FACC15"
          stroke={INK}
          strokeWidth={1.3}
        />
      </g>
    );
  }

  return drop;
}

function Callout({ placement, lift, index }: { placement: Placement; lift: number; index: number }) {
  const h = PART_HEIGHT[placement.part.kind];
  const [ax, ay] = project([placement.x, placement.y, placement.z + lift + h]);
  const text = partCallout(placement.part);
  const width = Math.min(text.length * 5.6 + 14, 150);
  const side = ax < -10 ? -1 : 1;
  const pillY = Math.max(VIEW.y + 6, ay - 30 - index * 4);
  const rawX = side > 0 ? ax + 34 : ax - 34 - width;
  const pillX = Math.min(Math.max(rawX, VIEW.x + 6), VIEW.x + VIEW.w - width - 6);
  const joinX = side > 0 ? pillX : pillX + width;
  return (
    <g>
      <path d={`M${ax} ${ay} L${joinX} ${pillY + 7.5}`} stroke={INK} strokeWidth={0.9} fill="none" />
      <circle cx={ax} cy={ay} r={2} fill={INK} />
      <rect x={pillX} y={pillY} width={width} height={15} rx={7.5} fill="#FFFFFF" stroke={INK} strokeWidth={1.2} />
      <text
        x={pillX + width / 2}
        y={pillY + 10.5}
        textAnchor="middle"
        fill={INK}
        fontSize={8.5}
        fontFamily="ui-monospace, monospace"
        fontWeight={700}
      >
        {text.length > 26 ? `${text.slice(0, 25)}…` : text}
      </text>
    </g>
  );
}

interface IsoStepDiagramProps {
  stepNumber: number;
  action: StepAction;
  active: Placement[];
  ghosts: Placement[];
  dimmed?: boolean;
}

export function IsoStepDiagram({ stepNumber, action, active, ghosts, dimmed = false }: IsoStepDiagramProps) {
  const id = useId().replace(/[^a-zA-Z0-9_-]/g, '');
  const markerId = `${id}-arrow`;
  const lift = liftFor(action);
  const sortedGhosts = [...ghosts].sort(byDepth);
  const sortedActive = [...active].sort(byDepth);
  const badge = `STEP ${String(stepNumber).padStart(2, '0')} · ${ACTION_LABEL[action]}`;
  const label = `Isometric diagram for step ${stepNumber}: ${ACTION_LABEL[action].toLowerCase()} ${
    active.map((placement) => partCallout(placement.part)).join(', ') || 'no new parts'
  }. ${ghosts.length} previously installed parts shown as gray ghosts.`;
  const primary = sortedActive[0];

  return (
    <svg
      viewBox={`${VIEW.x} ${VIEW.y} ${VIEW.w} ${VIEW.h}`}
      role="img"
      aria-label={label}
      className={`w-full rounded-xl border border-[#C9D6E4] dark:brightness-90 ${dimmed ? 'opacity-70 grayscale-[35%]' : ''}`}
    >
      <IsoGridDefs id={id} />
      <defs>
        <marker id={markerId} viewBox="0 0 10 10" refX={6} refY={5} markerWidth={5} markerHeight={5} orient="auto-start-reverse">
          <path d="M0 0 L10 5 L0 10 Z" fill={ARROW} />
        </marker>
      </defs>
      <rect x={VIEW.x} y={VIEW.y} width={VIEW.w} height={VIEW.h} fill={`url(#${id}-paper)`} />
      <rect x={VIEW.x} y={VIEW.y} width={VIEW.w} height={VIEW.h} fill={`url(#${id}-grid)`} />

      <IsoPlatform id={id} />
      <DimensionLine from={[-80, 60, -6]} to={[80, 60, -6]} offset={[0, 12, 0]} />
      <DimensionLine from={[80, -60, -6]} to={[80, 60, -6]} offset={[12, 0, 0]} />

      {sortedGhosts.map((placement) => (
        <g key={placement.key} opacity={0.6}>
          <IsoPart kind={placement.part.kind} at={[placement.x, placement.y, placement.z]} variant="ghost" />
        </g>
      ))}

      {sortedActive.map((placement) => {
        const [sx, sy] = project([placement.x, placement.y, placement.z]);
        const [w] = PART_FOOTPRINT[placement.part.kind];
        return (
          <g key={`fp-${placement.key}`}>
            {lift > 0 && <Footprint placement={placement} />}
            <ellipse cx={sx} cy={sy} rx={w * 0.55} ry={w * 0.22} fill="#0F172A" opacity={0.12} filter={`url(#${id}-blur)`} />
          </g>
        );
      })}

      {sortedActive.map((placement) => {
        const top = project([placement.x, placement.y, placement.z + lift + PART_HEIGHT[placement.part.kind] + 18]);
        const bottom = project([placement.x, placement.y, placement.z - 4]);
        return (
          <path
            key={`axis-${placement.key}`}
            d={`M${top[0]} ${top[1]} L${bottom[0]} ${bottom[1]}`}
            stroke={AXIS}
            strokeWidth={0.9}
            strokeDasharray="5 3 1 3"
          />
        );
      })}

      {sortedActive.map((placement) => (
        <IsoPart key={placement.key} kind={placement.part.kind} at={[placement.x, placement.y, placement.z + lift]} variant="active" />
      ))}

      {sortedActive.map((placement) => (
        <MotionArrow key={`arrow-${placement.key}`} placement={placement} lift={lift} action={action} markerId={markerId} />
      ))}

      {primary && lift > 0 && (
        <DimensionLine
          from={[primary.x - PART_FOOTPRINT[primary.part.kind][0] / 2, primary.y + PART_FOOTPRINT[primary.part.kind][1] / 2, primary.z + lift]}
          to={[primary.x + PART_FOOTPRINT[primary.part.kind][0] / 2, primary.y + PART_FOOTPRINT[primary.part.kind][1] / 2, primary.z + lift]}
          offset={[0, 8, 0]}
        />
      )}

      {sortedActive.slice(0, 4).map((placement, index) => (
        <Callout key={`callout-${placement.key}`} placement={placement} lift={lift} index={index} />
      ))}

      <g>
        <rect x={VIEW.x + 10} y={VIEW.y + 10} width={badge.length * 6.2 + 16} height={18} rx={4} fill={INK} />
        <text
          x={VIEW.x + 18}
          y={VIEW.y + 22.5}
          fill="#F1F5F9"
          fontSize={9.5}
          fontFamily="ui-monospace, monospace"
          fontWeight={700}
          letterSpacing={0.8}
        >
          {badge}
        </text>
      </g>
      {active.length > 4 && (
        <text x={VIEW.x + VIEW.w - 10} y={VIEW.y + VIEW.h - 10} textAnchor="end" fill={INK} fontSize={9} fontFamily="ui-monospace, monospace">
          +{active.length - 4} more in tray
        </text>
      )}
    </svg>
  );
}
