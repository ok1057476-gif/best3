import type { StepPart } from '@/types/blueprint';
import { IsoPart } from '@/components/iso/IsoPart';

export function PartsTray({ parts }: { parts: StepPart[] }) {
  return (
    <aside aria-labelledby="parts-tray-heading" className="flex flex-col gap-2 rounded-xl border-2 border-[#C9D6E4] dark:brightness-90 bg-[#EEF3F8] p-2.5 md:w-52 md:shrink-0">
      <h3 id="parts-tray-heading" className="px-1 font-mono text-[11px] font-bold uppercase tracking-wider text-slate-600">
        Parts tray
      </h3>
      {parts.length === 0 ? (
        <p className="rounded-lg border border-dashed border-[#B6C6D8] bg-white/60 px-3 py-4 text-center text-sm text-slate-500">
          No new parts on this page
        </p>
      ) : (
        <ul className="grid grid-cols-2 gap-2 md:grid-cols-1">
          {parts.map((part, index) => (
            <li key={`${part.label}-${index}`} className="relative flex items-center gap-2 rounded-lg border border-dashed border-[#B6C6D8] bg-white p-1.5">
              <svg viewBox="-48 -48 96 76" aria-hidden="true" className="size-14 shrink-0">
                <IsoPart kind={part.kind} at={[0, 0, 0]} variant="active" />
              </svg>
              <div className="min-w-0">
                <p className="font-mono text-lg font-bold leading-none text-slate-900">x{part.quantity}</p>
                <p className="mt-1 truncate text-xs text-slate-600" title={part.label}>
                  {part.label}
                </p>
              </div>
            </li>
          ))}
        </ul>
      )}
    </aside>
  );
}
