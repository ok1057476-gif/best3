import type { StepPartKind } from '@/types/blueprint';
import { isoEllipse, mix, project, toPoints, type Vec3 } from '@/lib/iso';

export const ANODIZED_BLUE = '#2F6FDB';
export const ANODIZED_ORANGE = '#F2782F';
const SLATE = '#334155';
const SLATE_DEEP = '#1E293B';
const LIGHT = '#FFFFFF';
const SHADE = '#0F172A';

const KIND_COLOR: Record<StepPartKind, string> = {
  board: ANODIZED_BLUE,
  panel: ANODIZED_ORANGE,
  screw: '#5B8DEF',
  wire: ANODIZED_ORANGE,
  sensor: ANODIZED_BLUE,
  battery: ANODIZED_ORANGE,
  led: '#F5A524',
  servo: ANODIZED_BLUE,
  button: ANODIZED_ORANGE,
  tape: ANODIZED_ORANGE,
  container: ANODIZED_BLUE,
};

export type PartVariant = 'active' | 'ghost';

interface Palette {
  body: string;
  detail: string;
  stroke: string;
  strokeWidth: number;
}

function paletteFor(kind: StepPartKind, variant: PartVariant): Palette {
  if (variant === 'ghost') {
    return { body: '#DCE3EB', detail: '#C5CFDA', stroke: '#A3B1C2', strokeWidth: 0.8 };
  }
  return { body: KIND_COLOR[kind], detail: SLATE_DEEP, stroke: SLATE, strokeWidth: 1.1 };
}

interface PrimitiveProps {
  at: Vec3;
  color: string;
  palette: Palette;
}

function Box({ at, size, color, palette }: PrimitiveProps & { size: Vec3 }) {
  const [cx, cy, z] = at;
  const [w, d, h] = size;
  const x0 = cx - w / 2;
  const x1 = cx + w / 2;
  const y0 = cy - d / 2;
  const y1 = cy + d / 2;
  const z1 = z + h;
  return (
    <g stroke={palette.stroke} strokeWidth={palette.strokeWidth} strokeLinejoin="round">
      <polygon points={toPoints([[x0, y1, z], [x1, y1, z], [x1, y1, z1], [x0, y1, z1]])} fill={color} />
      <polygon points={toPoints([[x1, y0, z], [x1, y1, z], [x1, y1, z1], [x1, y0, z1]])} fill={mix(color, SHADE, 0.24)} />
      <polygon points={toPoints([[x0, y0, z1], [x1, y0, z1], [x1, y1, z1], [x0, y1, z1]])} fill={mix(color, LIGHT, 0.32)} />
    </g>
  );
}

function Cylinder({ at, radius, height, color, palette }: PrimitiveProps & { radius: number; height: number }) {
  const [x, y, z] = at;
  const [cx, top] = project([x, y, z + height]);
  const [, bottom] = project([x, y, z]);
  const { rx, ry } = isoEllipse(radius);
  const side = `M${cx - rx} ${top} L${cx - rx} ${bottom} A${rx} ${ry} 0 0 0 ${cx + rx} ${bottom} L${cx + rx} ${top}`;
  const shadeHalf = `M${cx} ${top + ry} L${cx} ${bottom + ry} A${rx} ${ry} 0 0 0 ${cx + rx} ${bottom} L${cx + rx} ${top} A${rx} ${ry} 0 0 1 ${cx} ${top + ry} Z`;
  return (
    <g strokeLinejoin="round">
      <path d={`${side} Z`} fill={color} />
      <path d={shadeHalf} fill={SHADE} opacity={0.18} />
      <path d={side} fill="none" stroke={palette.stroke} strokeWidth={palette.strokeWidth} />
      <ellipse cx={cx} cy={top} rx={rx} ry={ry} fill={mix(color, LIGHT, 0.32)} stroke={palette.stroke} strokeWidth={palette.strokeWidth} />
    </g>
  );
}

function SurfaceHole({ at, radius, fill }: { at: Vec3; radius: number; fill: string }) {
  const [cx, cy] = project(at);
  const { rx, ry } = isoEllipse(radius);
  return <ellipse cx={cx} cy={cy} rx={rx} ry={ry} fill={fill} />;
}

function Wire({ at, palette, variant }: { at: Vec3; palette: Palette; variant: PartVariant }) {
  const [ox, oy, oz] = at;
  const strands = [
    { offset: -6, color: variant === 'ghost' ? palette.body : ANODIZED_ORANGE },
    { offset: 6, color: variant === 'ghost' ? palette.body : '#3B4252' },
  ];
  return (
    <g fill="none" strokeLinecap="round" strokeLinejoin="round">
      {strands.map(({ offset, color }) => {
        const path = Array.from({ length: 13 }, (_, index) => {
          const x = -28 + index * (56 / 12);
          const y = offset + Math.sin(x / 9) * 5;
          const [sx, sy] = project([ox + x, oy + y, oz + 2]);
          return `${index === 0 ? 'M' : 'L'}${sx.toFixed(2)} ${sy.toFixed(2)}`;
        }).join(' ');
        return (
          <g key={offset}>
            <path d={path} stroke={palette.stroke} strokeWidth={variant === 'ghost' ? 3 : 5} />
            <path d={path} stroke={color} strokeWidth={variant === 'ghost' ? 1.6 : 3} />
          </g>
        );
      })}
      {[-30, 30].map((x) =>
        strands.map(({ offset }) => (
          <Box
            key={`${x}${offset}`}
            at={[ox + x, oy + offset + Math.sin(x / 9) * 5, oz]}
            size={[6, 5, 5]}
            color={variant === 'ghost' ? palette.detail : SLATE_DEEP}
            palette={palette}
          />
        )),
      )}
    </g>
  );
}

interface IsoPartProps {
  kind: StepPartKind;
  at: Vec3;
  variant: PartVariant;
}

export function IsoPart({ kind, at, variant }: IsoPartProps) {
  const palette = paletteFor(kind, variant);
  const [x, y, z] = at;
  const body = palette.body;
  const detail = palette.detail;

  switch (kind) {
    case 'board':
      return (
        <g>
          <Box at={[x, y, z]} size={[60, 40, 4]} color={body} palette={palette} />
          {[-24, -17, -10, -3, 4, 11, 18, 25].map((px) => (
            <Box key={px} at={[x + px, y - 15, z + 4]} size={[3, 3, 5]} color={detail} palette={palette} />
          ))}
          <Box at={[x - 2, y + 4, z + 4]} size={[16, 16, 4]} color={detail} palette={palette} />
        </g>
      );
    case 'panel':
      return (
        <g>
          <Box at={[x, y, z]} size={[70, 50, 4]} color={body} palette={palette} />
          {[
            [-29, -19],
            [29, -19],
            [-29, 19],
            [29, 19],
          ].map(([hx, hy]) => (
            <SurfaceHole key={`${hx}${hy}`} at={[x + hx, y + hy, z + 4]} radius={3} fill={mix(body, SHADE, 0.45)} />
          ))}
        </g>
      );
    case 'screw':
      return (
        <g>
          {[-14, 0, 14].map((sx) => {
            const [hx, hy] = project([x + sx, y, z + 17]);
            return (
              <g key={sx}>
                <Cylinder at={[x + sx, y, z]} radius={1.8} height={14} color={body} palette={palette} />
                <Cylinder at={[x + sx, y, z + 14]} radius={5} height={3} color={body} palette={palette} />
                <path
                  d={`M${hx - 3} ${hy - 1.5} L${hx + 3} ${hy + 1.5} M${hx - 3} ${hy + 1.5} L${hx + 3} ${hy - 1.5}`}
                  stroke={palette.stroke}
                  strokeWidth={1.2}
                  strokeLinecap="round"
                />
              </g>
            );
          })}
        </g>
      );
    case 'wire':
      return <Wire at={at} palette={palette} variant={variant} />;
    case 'sensor':
      return (
        <g>
          <Box at={[x, y, z]} size={[40, 20, 3]} color={body} palette={palette} />
          <Cylinder at={[x - 10, y, z + 3]} radius={7} height={8} color={mix(body, LIGHT, 0.55)} palette={palette} />
          <Cylinder at={[x + 10, y, z + 3]} radius={7} height={8} color={mix(body, LIGHT, 0.55)} palette={palette} />
        </g>
      );
    case 'battery':
      return (
        <g>
          <Box at={[x, y, z]} size={[46, 26, 18]} color={body} palette={palette} />
          <Cylinder at={[x + 14, y - 4, z + 18]} radius={3.5} height={3} color={detail} palette={palette} />
          <Cylinder at={[x - 14, y - 4, z + 18]} radius={3.5} height={3} color={detail} palette={palette} />
        </g>
      );
    case 'led': {
      const [cx, top] = project([x, y, z + 18]);
      const { rx, ry } = isoEllipse(6);
      return (
        <g>
          <Box at={[x - 2, y, z]} size={[1.6, 1.6, 8]} color={detail} palette={palette} />
          <Box at={[x + 2, y, z]} size={[1.6, 1.6, 6]} color={detail} palette={palette} />
          <Cylinder at={[x, y, z + 6]} radius={7.5} height={2} color={body} palette={palette} />
          <Cylinder at={[x, y, z + 8]} radius={6} height={10} color={body} palette={palette} />
          <path
            d={`M${cx - rx} ${top} A${rx} ${rx * 0.95} 0 0 1 ${cx + rx} ${top} A${rx} ${ry} 0 0 1 ${cx - rx} ${top} Z`}
            fill={mix(body, LIGHT, 0.4)}
            stroke={palette.stroke}
            strokeWidth={palette.strokeWidth}
          />
        </g>
      );
    }
    case 'servo':
      return (
        <g>
          <Box at={[x, y, z]} size={[40, 20, 26]} color={body} palette={palette} />
          <Box at={[x, y, z + 18]} size={[54, 20, 3]} color={body} palette={palette} />
          <Cylinder at={[x - 10, y, z + 26]} radius={6} height={4} color={mix(body, LIGHT, 0.5)} palette={palette} />
          <Box at={[x - 2, y, z + 30]} size={[26, 6, 2]} color={mix(body, LIGHT, 0.6)} palette={palette} />
        </g>
      );
    case 'button':
      return (
        <g>
          <Box at={[x, y, z]} size={[26, 26, 6]} color={variant === 'ghost' ? body : '#64748B'} palette={palette} />
          <Cylinder at={[x, y, z + 6]} radius={8} height={5} color={body} palette={palette} />
        </g>
      );
    case 'tape':
      return (
        <g>
          <Cylinder at={[x, y, z]} radius={18} height={10} color={body} palette={palette} />
          <SurfaceHole at={[x, y, z + 10]} radius={8} fill={variant === 'ghost' ? '#EEF2F6' : '#E8EEF5'} />
        </g>
      );
    case 'container': {
      const h = 34;
      const inset = 3;
      const x0 = x - 30 + inset;
      const x1 = x + 30 - inset;
      const y0 = y - 22 + inset;
      const y1 = y + 22 - inset;
      return (
        <g>
          <Box at={[x, y, z]} size={[60, 44, h]} color={body} palette={palette} />
          <polygon
            points={toPoints([[x0, y0, z + h], [x1, y0, z + h], [x1, y1, z + h], [x0, y1, z + h]])}
            fill={mix(body, SHADE, 0.38)}
            stroke={palette.stroke}
            strokeWidth={palette.strokeWidth * 0.8}
          />
        </g>
      );
    }
  }
}
