import { useId } from 'react';
import { byDepth, type Placement } from '@/lib/iso';
import { IsoPart } from '@/components/iso/IsoPart';
import { IsoGridDefs, IsoPlatform } from '@/components/iso/IsoScene';

export function IsoAssemblyThumb({ placements, title }: { placements: Placement[]; title: string }) {
  const id = useId().replace(/[^a-zA-Z0-9_-]/g, '');
  const sorted = [...placements].sort(byDepth);
  return (
    <figure className="w-36 shrink-0 overflow-hidden rounded-xl border border-[#C9D6E4] dark:brightness-90 bg-white shadow-sm sm:w-44">
      <svg viewBox="-140 -105 280 185" role="img" aria-label={`Final assembly of ${title}`} className="block w-full">
        <IsoGridDefs id={id} />
        <rect x={-140} y={-105} width={280} height={185} fill={`url(#${id}-paper)`} />
        <rect x={-140} y={-105} width={280} height={185} fill={`url(#${id}-grid)`} />
        <IsoPlatform id={id} />
        {sorted.map((placement) => (
          <IsoPart key={placement.key} kind={placement.part.kind} at={[placement.x, placement.y, placement.z]} variant="active" />
        ))}
      </svg>
      <figcaption className="border-t border-[#E5E1D8] px-2.5 py-1.5 font-mono text-[10px] font-bold uppercase tracking-wider text-stone-500">
        Final build
      </figcaption>
    </figure>
  );
}
