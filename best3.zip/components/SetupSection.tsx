'use client';

import { useRef, useState } from 'react';
import { Loader2, Sparkles, Wand2, X } from 'lucide-react';
import type { RegionCode } from '@/utils/regionConfig';
import { formatPrice } from '@/utils/regionConfig';
import type { Translation } from '@/utils/i18n';
import { SketchPad } from '@/components/SketchPad';

interface GenerateParams {
  idea: string;
  sketchImageBase64?: string;
  sketchImageMimeType?: string;
  budget: number;
  comfortLevel: 'beginner' | 'ready_to_learn';
  enclosurePreference: string;
  hasPrinter: boolean;
}

interface SetupSectionProps {
  defaultHasPrinter: boolean;
  userName: string;
  onUpdateUserName: (name: string) => void;
  selectedRegion: RegionCode;
  t: Translation;
  onGenerate: (params: GenerateParams) => void;
  isLoading: boolean;
  isCollapsible: boolean;
  onClose: () => void;
}

const ENCLOSURES = ['Cardboard', '3D Printed', 'Wood', 'Acrylic / Plastic', 'Metal'];
const AUTO = 'auto';
const BUDGET_MIN = 5;
const BUDGET_SLIDER_MAX = 1000;
const BUDGET_INPUT_MAX = 100000;

const MATERIAL_HINTS: { material: string; keywords: string[] }[] = [
  { material: 'Metal', keywords: ['metal', 'steel', 'aluminum', 'outdoor', 'grill', 'heavy', 'rugged', 'bike'] },
  { material: 'Acrylic / Plastic', keywords: ['acrylic', 'plastic', 'jar', 'glow', 'lamp', 'light', 'display', 'aquarium', 'waterproof'] },
  { material: '3D Printed', keywords: ['robot', 'drone', 'gear', 'mount', 'bracket', 'case', 'enclosure', 'claw'] },
  { material: 'Wood', keywords: ['shelf', 'clock', 'frame', 'planter', 'table', 'desk', 'birdhouse', 'sign'] },
  { material: 'Cardboard', keywords: ['box', 'cereal', 'cardboard', 'paper'] },
];

const PRINTED = '3D Printed';

function inferMaterial(idea: string, hasPrinter: boolean): string {
  const text = idea.toLowerCase();
  return (
    MATERIAL_HINTS.find(
      ({ material, keywords }) => (hasPrinter || material !== PRINTED) && keywords.some((k) => text.includes(k))
    )?.material ?? 'Cardboard'
  );
}

export function SetupSection({
  defaultHasPrinter,
  userName,
  selectedRegion,
  t,
  onGenerate,
  isLoading,
  isCollapsible,
  onClose,
}: SetupSectionProps) {
  const [idea, setIdea] = useState('');
  const [budget, setBudget] = useState(30);
  const [budgetText, setBudgetText] = useState('30');

  const updateBudget = (value: number) => {
    const clamped = Math.min(BUDGET_INPUT_MAX, Math.max(BUDGET_MIN, Math.round(value)));
    setBudget(clamped);
    setBudgetText(String(clamped));
  };

  const handleBudgetTextChange = (raw: string) => {
    const digits = raw.replace(/[^\d]/g, '');
    setBudgetText(digits);
    const parsed = Number(digits);
    if (digits && parsed >= BUDGET_MIN && parsed <= BUDGET_INPUT_MAX) setBudget(parsed);
  };

  const localPrice = formatPrice(budget, selectedRegion);
  const [comfortLevel, setComfortLevel] = useState<'beginner' | 'ready_to_learn'>('beginner');
  const [enclosure, setEnclosure] = useState(AUTO);
  const [hasPrinter, setHasPrinter] = useState(defaultHasPrinter);
  const [syncedDefaultPrinter, setSyncedDefaultPrinter] = useState(defaultHasPrinter);
  if (syncedDefaultPrinter !== defaultHasPrinter) {
    setSyncedDefaultPrinter(defaultHasPrinter);
    setHasPrinter(defaultHasPrinter);
  }
  const activeEnclosure = !hasPrinter && enclosure === PRINTED ? AUTO : enclosure;
  const enclosureOptions = hasPrinter ? ENCLOSURES : ENCLOSURES.filter((option) => option !== PRINTED);
  const smartMaterial = inferMaterial(idea, hasPrinter);
  const isAuto = activeEnclosure === AUTO;
  const resolvedMaterial = isAuto ? smartMaterial : activeEnclosure;
  const [hasSketch, setHasSketch] = useState(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!idea.trim() || isLoading) return;
    const dataUrl = hasSketch ? canvasRef.current?.toDataURL('image/png') : undefined;
    onGenerate({
      idea: idea.trim(),
      sketchImageBase64: dataUrl?.split(',')[1],
      sketchImageMimeType: dataUrl ? 'image/png' : undefined,
      budget,
      comfortLevel,
      enclosurePreference: resolvedMaterial,
      hasPrinter,
    });
  };

  return (
    <section
      aria-labelledby="setup-title"
      className="relative mb-8 rounded-2xl border border-line bg-surface p-5 shadow-sm sm:p-8"
    >
      {isCollapsible && (
        <button
          type="button"
          onClick={onClose}
          aria-label={t.close}
          className="absolute right-2 top-2 flex size-12 cursor-pointer md:right-4 md:top-4 md:size-8 items-center justify-center rounded-lg text-stone-500 transition-colors hover:bg-sunken hover:text-stone-900"
        >
          <X className="size-4" aria-hidden="true" />
        </button>
      )}

      <h1 id="setup-title" className="text-balance text-3xl font-bold tracking-tight sm:text-4xl">
        {userName ? `${userName}, ${t.heroTitle.charAt(0).toLowerCase()}${t.heroTitle.slice(1)}` : t.heroTitle}
      </h1>
      <p className="mt-2 text-pretty text-stone-600">{t.heroSubtitle}</p>

      <form
        onSubmit={handleSubmit}
        className="mt-6 overflow-hidden rounded-xl border border-line bg-paper"
      >
        <div className="grid gap-5 p-4 sm:p-5 md:grid-cols-2 md:gap-6">
        <div className="flex flex-col gap-4">
          <label className="sr-only" htmlFor="idea-input">
            {t.heroTitle}
          </label>
          <textarea
            id="idea-input"
            value={idea}
            onChange={(e) => setIdea(e.target.value)}
            placeholder={t.ideaPlaceholder}
            rows={4}
            className="w-full resize-none rounded-xl border border-line bg-surface p-4 outline-none transition-shadow focus:border-stone-400 focus:ring-2"
            style={{ ['--tw-ring-color' as string]: 'color-mix(in oklab, var(--phenom-accent) 30%, transparent)' }}
          />

          <div className="flex flex-col gap-4">
            <div className="flex flex-col gap-1.5">
              <div className="flex items-center justify-between gap-2">
                <label htmlFor="budget" className="text-sm font-semibold">
                  {t.budget}
                </label>
                <div className="flex items-center gap-1.5">
                  {!localPrice.startsWith('$') && (
                    <span className="text-xs text-stone-500">{`≈ ${localPrice}`}</span>
                  )}
                  <label htmlFor="budget-custom" className="sr-only">
                    {t.customBudget}
                  </label>
                  <div className="flex h-12 items-center rounded-md border border-line bg-paper px-3 text-sm focus-within:border-stone-400 md:h-auto md:px-2 md:py-0.5">
                    <span className="text-stone-500" aria-hidden="true">
                      $
                    </span>
                    <input
                      id="budget-custom"
                      type="text"
                      inputMode="numeric"
                      value={budgetText}
                      onChange={(e) => handleBudgetTextChange(e.target.value)}
                      onBlur={() => updateBudget(Number(budgetText) || BUDGET_MIN)}
                      className="w-16 bg-transparent text-right font-semibold tabular-nums outline-none"
                    />
                  </div>
                </div>
              </div>
              <input
                id="budget"
                type="range"
                min={BUDGET_MIN}
                max={BUDGET_SLIDER_MAX}
                step={5}
                value={Math.min(budget, BUDGET_SLIDER_MAX)}
                onChange={(e) => updateBudget(Number(e.target.value))}
                aria-valuetext={`$${budget}`}
                className="h-12 cursor-pointer md:h-auto"
                style={{ accentColor: 'var(--phenom-accent)' }}
              />
              <div className="flex justify-between text-xs text-stone-400" aria-hidden="true">
                <span>{`$${BUDGET_MIN}`}</span>
                <span>{`$${BUDGET_SLIDER_MAX.toLocaleString()}+`}</span>
              </div>
            </div>

            <fieldset className="flex flex-col gap-1.5">
              <legend className="mb-1.5 text-sm font-semibold">{t.comfortLevel}</legend>
              <div className="flex rounded-lg border border-line bg-sunken p-0.5 text-sm">
                {(['beginner', 'ready_to_learn'] as const).map((level) => (
                  <button
                    key={level}
                    type="button"
                    aria-pressed={comfortLevel === level}
                    onClick={() => setComfortLevel(level)}
                    className={`min-h-12 flex-1 cursor-pointer rounded-md px-2 py-1 transition-colors md:min-h-0 ${
                      comfortLevel === level ? 'bg-surface font-semibold shadow-sm' : 'text-stone-500 hover:text-stone-800'
                    }`}
                  >
                    {level === 'beginner' ? t.beginner : t.readyToLearn}
                  </button>
                ))}
              </div>
            </fieldset>

          </div>

          <div className="flex flex-col gap-1.5">
            <label htmlFor="enclosure" className="text-sm font-semibold">
              {t.madeOf}
            </label>
            <select
              id="enclosure"
              value={activeEnclosure}
              onChange={(e) => setEnclosure(e.target.value)}
              aria-describedby={isAuto ? 'enclosure-help' : undefined}
              className="h-12 w-full cursor-pointer rounded-lg border border-line bg-surface px-3 py-2 text-sm outline-none focus:border-stone-400 md:h-auto"
            >
              <option value={AUTO}>{t.autoDetect}</option>
              {enclosureOptions.map((option) => (
                <option key={option} value={option}>
                  {option}
                </option>
              ))}
            </select>
            {isAuto && (
              <p id="enclosure-help" className="flex items-center gap-1.5 text-xs text-stone-500">
                <Sparkles className="size-3 shrink-0" style={{ color: 'var(--phenom-accent)' }} aria-hidden="true" />
                {t.autoDetectHelp}
              </p>
            )}
          </div>

          <fieldset className="flex flex-col gap-1.5">
            <legend className="mb-1.5 text-sm font-semibold">{t.printer}</legend>
            <div className="flex rounded-lg border border-line bg-sunken p-0.5 text-sm">
              {([false, true] as const).map((available) => (
                <button
                  key={String(available)}
                  type="button"
                  aria-pressed={hasPrinter === available}
                  onClick={() => setHasPrinter(available)}
                  className={`min-h-12 flex-1 cursor-pointer rounded-md px-2 py-1 transition-colors md:min-h-0 ${
                    hasPrinter === available ? 'bg-surface font-semibold shadow-sm' : 'text-stone-500 hover:text-stone-800'
                  }`}
                >
                  {available ? t.hasPrinter : t.noPrinter}
                </button>
              ))}
            </div>
          </fieldset>

        </div>

        <SketchPad t={t} canvasRef={canvasRef} hasSketch={hasSketch} onHasSketchChange={setHasSketch} />
        </div>

        <div className="border-t border-line bg-surface-alt p-4 sm:px-5">
          <button
            type="submit"
            disabled={!idea.trim() || isLoading}
            className="flex min-h-12 w-full cursor-pointer items-center justify-center gap-2 rounded-xl px-5 py-4 font-semibold text-white transition-opacity hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50 md:min-h-0 md:py-3.5"
            style={{ backgroundColor: 'var(--phenom-accent)' }}
          >
            {isLoading ? (
              <Loader2 className="size-4 animate-spin" aria-hidden="true" />
            ) : (
              <Wand2 className="size-4" aria-hidden="true" />
            )}
            {isLoading ? t.generating : t.generate}
          </button>
        </div>
      </form>
    </section>
  );
}
