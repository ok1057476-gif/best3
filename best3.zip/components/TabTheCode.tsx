'use client';

import { useState } from 'react';
import { Check, Copy, FileCode2 } from 'lucide-react';
import type { Blueprint } from '@/types/blueprint';
import type { Translation } from '@/utils/i18n';

interface TabTheCodeProps {
  blueprint: Blueprint;
  t: Translation;
}

export function TabTheCode({ blueprint, t }: TabTheCodeProps) {
  const [copied, setCopied] = useState(false);

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(blueprint.code.source);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    } catch {
      setCopied(false);
    }
  };

  return (
    <section className="overflow-hidden rounded-2xl border border-neutral-800 bg-neutral-900 text-neutral-100">
      <div className="flex items-center justify-between border-b border-neutral-700 px-4 py-2.5">
        <span className="flex items-center gap-2 font-mono text-sm text-neutral-300">
          <FileCode2 className="size-4" aria-hidden="true" />
          {blueprint.code.filename}
        </span>
        <button
          type="button"
          onClick={handleCopy}
          className="flex cursor-pointer items-center gap-1.5 rounded-md px-2.5 py-1 text-sm font-semibold text-neutral-300 hover:bg-neutral-800 hover:text-white"
        >
          {copied ? <Check className="size-4" aria-hidden="true" /> : <Copy className="size-4" aria-hidden="true" />}
          <span aria-live="polite">{copied ? t.copied : t.copy}</span>
        </button>
      </div>
      <pre className="overflow-x-auto p-5 font-mono text-sm leading-relaxed">
        <code>{blueprint.code.source}</code>
      </pre>
    </section>
  );
}
