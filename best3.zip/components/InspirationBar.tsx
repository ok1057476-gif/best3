import { ArrowRight, Bookmark } from 'lucide-react';
import { FEATURED_BLUEPRINTS } from '@/data/seedBlueprints';
import type { Translation } from '@/utils/i18n';

interface InspirationBarProps {
  activeBlueprintId?: string;
  savedProjectIds: string[];
  t: Translation;
  onToggleBookmark: (id: string) => void;
  onSelectProject: (id: string) => void;
  onOpenShowcaseTab: () => void;
}

export function InspirationBar({
  activeBlueprintId,
  savedProjectIds,
  t,
  onToggleBookmark,
  onSelectProject,
  onOpenShowcaseTab,
}: InspirationBarProps) {
  return (
    <section aria-labelledby="inspiration-title" className="mb-8">
      <div className="mb-3 flex items-center justify-between">
        <h2 id="inspiration-title" className="text-sm font-bold uppercase tracking-wider text-stone-500">
          {t.inspiration}
        </h2>
        <button
          type="button"
          onClick={onOpenShowcaseTab}
          className="flex cursor-pointer items-center gap-1 text-sm font-semibold text-stone-600 hover:text-stone-900"
        >
          {t.seeShowcase}
          <ArrowRight className="size-3.5" aria-hidden="true" />
        </button>
      </div>
      <ul className="flex gap-3 overflow-x-auto pb-2">
        {FEATURED_BLUEPRINTS.map((project) => {
          const isActive = project.id === activeBlueprintId;
          const isSaved = savedProjectIds.includes(project.id);
          return (
            <li
              key={project.id}
              className={`relative flex w-64 shrink-0 flex-col rounded-xl border bg-surface transition-colors ${
                isActive ? 'border-stone-900' : 'border-line hover:border-stone-400'
              }`}
            >
              <button
                type="button"
                onClick={() => onSelectProject(project.id)}
                aria-current={isActive ? 'true' : undefined}
                className="flex flex-1 cursor-pointer flex-col gap-1 p-4 pr-12 text-left"
              >
                <span className="font-semibold leading-snug">{project.title}</span>
                <span className="line-clamp-2 text-sm text-stone-500">{project.tagline}</span>
                <span className="mt-2 text-xs font-medium text-stone-400">
                  {project.difficulty} · {project.estimatedTime}
                </span>
              </button>
              <button
                type="button"
                onClick={() => onToggleBookmark(project.id)}
                aria-pressed={isSaved}
                aria-label={`Bookmark ${project.title}`}
                className="absolute right-3 top-3 flex size-8 cursor-pointer items-center justify-center rounded-lg hover:bg-sunken"
              >
                <Bookmark
                  className="size-4"
                  aria-hidden="true"
                  style={isSaved ? { fill: 'var(--phenom-accent)', color: 'var(--phenom-accent)' } : undefined}
                />
              </button>
            </li>
          );
        })}
      </ul>
    </section>
  );
}
