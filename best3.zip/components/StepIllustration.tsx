import { useId } from 'react';
import type { StepAction, StepPart, StepPartKind } from '@/types/blueprint';

const INK = '#1E293B';
const MUTED = '#9AAEC4';
const GRID_MINOR = '#D5E1EE';
const GRID_MAJOR = '#BCCDE0';
const PAPER = '#EDF3F9';
const ARROW = '#D9644A';

const KIND_FILL: Record<StepPartKind, string> = {
  board: '#3E8E8A',
  panel: '#E8B04A',
  screw: '#B8C0CC',
  wire: '#D9644A',
  sensor: '#4A6FA5',
  battery: '#D9644A',
  led: '#F2C94C',
  servo: '#4A6FA5',
  button: '#D9644A',
  tape: '#E8B04A',
  container: '#C9A27A',
};

const ACTION_LABEL: Record<StepAction, string> = {
  place: 'PLACE',
  snap: 'SNAP IN',
  screw: 'SCREW IN',
  slot: 'SLOT IN',
  connect: 'CONNECT',
  glue: 'GLUE',
  cut: 'CUT',
  test: 'TEST',
};

const TARGET = { x: 100, y: 112 };
const MUTED_SLOTS = [
  { x: 78, y: 96 },
  { x: 124, y: 124 },
  { x: 88, y: 148 },
  { x: 132, y: 84 },
];

type Variant = 'active' | 'muted';

function PartShape({ kind, variant }: { kind: StepPartKind; variant: Variant }) {
  const active = variant === 'active';
  const fill = active ? KIND_FILL[kind] : 'none';
  const stroke = active ? INK : MUTED;
  const sw = active ? 2.5 : 1.5;
  const detail = active ? INK : MUTED;
  const common = { stroke, strokeWidth: sw, strokeLinejoin: 'round' as const };

  switch (kind) {
    case 'board':
      return (
        <g>
          <rect x={-26} y={-17} width={52} height={34} rx={3} fill={fill} {...common} />
          <rect x={-8} y={-7} width={16} height={14} rx={1.5} fill={active ? INK : 'none'} stroke={detail} strokeWidth={1.5} />
          {[-20, -14, -8, -2, 4, 10, 16].map((x) => (
            <circle key={x} cx={x + 2} cy={-12} r={1.4} fill={detail} />
          ))}
        </g>
      );
    case 'panel':
      return (
        <g>
          <rect x={-28} y={-18} width={56} height={36} rx={2} fill={fill} {...common} />
          {[
            [-22, -12],
            [22, -12],
            [-22, 12],
            [22, 12],
          ].map(([cx, cy]) => (
            <circle key={`${cx}${cy}`} cx={cx} cy={cy} r={2.5} fill={active ? PAPER : 'none'} stroke={detail} strokeWidth={1.5} />
          ))}
        </g>
      );
    case 'screw':
      return (
        <g>
          {[-14, 0, 14].map((x) => (
            <g key={x} transform={`translate(${x} 0)`}>
              <rect x={-2.5} y={-2} width={5} height={16} fill={fill} {...common} strokeWidth={active ? 2 : 1.25} />
              <circle cx={0} cy={-6} r={6} fill={fill} {...common} strokeWidth={active ? 2 : 1.25} />
              <path d="M-3 -6 H3 M0 -9 V-3" stroke={detail} strokeWidth={1.5} strokeLinecap="round" />
            </g>
          ))}
        </g>
      );
    case 'wire':
      return (
        <g fill="none" strokeLinecap="round">
          <path d="M-26 -8 C-10 -22, 6 8, 26 -8" stroke={active ? INK : MUTED} strokeWidth={active ? 6 : 3} />
          <path d="M-26 -8 C-10 -22, 6 8, 26 -8" stroke={active ? '#D9644A' : 'none'} strokeWidth={3} />
          <path d="M-26 8 C-10 -6, 6 24, 26 8" stroke={active ? INK : MUTED} strokeWidth={active ? 6 : 3} />
          <path d="M-26 8 C-10 -6, 6 24, 26 8" stroke={active ? '#3A3F47' : 'none'} strokeWidth={3} />
        </g>
      );
    case 'sensor':
      return (
        <g>
          <rect x={-10} y={-18} width={20} height={24} rx={2} fill={fill} {...common} />
          <path d="M-6 6 V20 M6 6 V20" stroke={stroke} strokeWidth={active ? 4 : 2} strokeLinecap="round" />
        </g>
      );
    case 'battery':
      return (
        <g>
          <rect x={-22} y={-12} width={44} height={24} rx={3} fill={fill} {...common} />
          <rect x={22} y={-5} width={5} height={10} rx={1} fill={active ? INK : 'none'} stroke={stroke} strokeWidth={1.5} />
          <path d="M-12 0 H-4 M-8 -4 V4 M6 0 H14" stroke={active ? PAPER : MUTED} strokeWidth={2} strokeLinecap="round" />
        </g>
      );
    case 'led':
      return (
        <g>
          <path d="M-9 4 V-6 A9 9 0 0 1 9 -6 V4 Z" fill={fill} {...common} />
          <rect x={-12} y={4} width={24} height={4} rx={1} fill={fill} {...common} strokeWidth={active ? 2 : 1.25} />
          <path d="M-4 8 V20 M4 8 V16" stroke={stroke} strokeWidth={2} strokeLinecap="round" />
        </g>
      );
    case 'servo':
      return (
        <g>
          <rect x={-20} y={-10} width={40} height={24} rx={2} fill={fill} {...common} />
          <circle cx={-8} cy={-10} r={5} fill={active ? PAPER : 'none'} stroke={stroke} strokeWidth={sw} />
          <path d="M-8 -10 L14 -18" stroke={stroke} strokeWidth={active ? 4 : 2} strokeLinecap="round" />
        </g>
      );
    case 'button':
      return (
        <g>
          <rect x={-14} y={-14} width={28} height={28} rx={3} fill={active ? '#E7ECF2' : 'none'} {...common} />
          <circle cx={0} cy={0} r={8} fill={fill} {...common} strokeWidth={active ? 2 : 1.25} />
        </g>
      );
    case 'tape':
      return (
        <g>
          <circle cx={0} cy={0} r={17} fill={fill} {...common} />
          <circle cx={0} cy={0} r={8} fill={active ? PAPER : 'none'} stroke={stroke} strokeWidth={sw} />
        </g>
      );
    case 'container':
      return (
        <g>
          <path d="M-24 -16 H24 L20 18 H-20 Z" fill={fill} {...common} />
          <path d="M-24 -16 L-18 -24 H18 L24 -16" fill="none" stroke={stroke} strokeWidth={sw} strokeLinejoin="round" />
        </g>
      );
  }
}

function ActionMark({ action }: { action: StepAction }) {
  const { x, y } = TARGET;
  const common = { fill: 'none', stroke: ARROW, strokeWidth: 2.5, strokeLinecap: 'round' as const };
  switch (action) {
    case 'screw':
      return (
        <g {...common}>
          <path d={`M${x - 16} ${y - 6} A17 17 0 1 1 ${x - 6} ${y + 15}`} />
          <path d={`M${x - 6} ${y + 15} l-2 -7 M${x - 6} ${y + 15} l-7 1`} />
        </g>
      );
    case 'snap':
      return (
        <g {...common}>
          <path d={`M${x - 22} ${y - 16} l-6 -6 M${x - 24} ${y} h-8 M${x - 22} ${y + 16} l-6 6`} />
        </g>
      );
    case 'slot':
      return (
        <g {...common} stroke={INK}>
          <path d={`M${x - 16} ${y - 4} V${y + 12} H${x + 16} V${y - 4}`} />
        </g>
      );
    case 'glue':
      return (
        <path
          d={`M${x} ${y - 14} C${x + 7} ${y - 4}, ${x + 8} ${y + 4}, ${x} ${y + 6} C${x - 8} ${y + 4}, ${x - 7} ${y - 4}, ${x} ${y - 14} Z`}
          fill="#F2C94C"
          stroke={INK}
          strokeWidth={2}
        />
      );
    case 'cut':
      return <path d={`M${x - 30} ${y + 20} L${x + 30} ${y - 20}`} {...common} strokeDasharray="5 4" />;
    case 'test':
      return (
        <path
          d={`M${x + 2} ${y - 16} L${x - 8} ${y + 2} H${x} L${x - 4} ${y + 16} L${x + 8} ${y - 4} H${x} Z`}
          fill="#F2C94C"
          stroke={INK}
          strokeWidth={2}
          strokeLinejoin="round"
        />
      );
    default:
      return null;
  }
}

function calloutText(part: StepPart) {
  return part.quantity > 1 ? `x${part.quantity} ${part.label}` : part.label;
}

interface StepIllustrationProps {
  parts: StepPart[];
  previousParts: StepPart[];
  action: StepAction;
  dimmed?: boolean;
}

export function StepIllustration({ parts, previousParts, action, dimmed = false }: StepIllustrationProps) {
  const rawId = useId();
  const id = rawId.replace(/[^a-zA-Z0-9_-]/g, '');
  const shown = parts.slice(0, 3);
  const hidden = parts.length - shown.length;
  const muted = previousParts.slice(-MUTED_SLOTS.length);
  const scale = shown.length === 3 ? 0.78 : 0.9;
  const rows = shown.length === 1 ? [108] : shown.length === 2 ? [76, 142] : [52, 108, 164];

  const label = `${ACTION_LABEL[action].toLowerCase()}: ${parts.map(calloutText).join(', ')}${
    previousParts.length ? `. ${previousParts.length} previously added parts shown faded.` : ''
  }`;

  return (
    <svg
      viewBox="0 0 320 200"
      role="img"
      aria-label={`Diagram, ${label}`}
      className={`w-full rounded-xl border border-[#C9D6E4] dark:brightness-90 ${dimmed ? 'opacity-60 grayscale-[40%]' : ''}`}
    >
      <defs>
        <pattern id={`${id}-minor`} width={16} height={16} patternUnits="userSpaceOnUse">
          <path d="M16 0 H0 V16" fill="none" stroke={GRID_MINOR} strokeWidth={0.75} />
        </pattern>
        <pattern id={`${id}-major`} width={64} height={64} patternUnits="userSpaceOnUse">
          <rect width={64} height={64} fill={`url(#${id}-minor)`} />
          <path d="M64 0 H0 V64" fill="none" stroke={GRID_MAJOR} strokeWidth={1} />
        </pattern>
        <marker id={`${id}-head`} viewBox="0 0 10 10" refX={7} refY={5} markerWidth={6} markerHeight={6} orient="auto-start-reverse">
          <path d="M0 0 L10 5 L0 10 Z" fill={ARROW} />
        </marker>
      </defs>

      <rect width={320} height={200} fill={PAPER} />
      <rect width={320} height={200} fill={`url(#${id}-major)`} />

      <g>
        <rect x={10} y={10} width={ACTION_LABEL[action].length * 7 + 14} height={18} rx={4} fill={INK} />
        <text x={17} y={23} fill={PAPER} fontSize={10} fontFamily="ui-monospace, monospace" fontWeight={700} letterSpacing={1}>
          {ACTION_LABEL[action]}
        </text>
      </g>

      {muted.length > 0 ? (
        muted.map((part, index) => {
          const slot = MUTED_SLOTS[index];
          return (
            <g key={`${part.label}-${index}`} transform={`translate(${slot.x} ${slot.y}) scale(0.72)`} opacity={0.85}>
              <PartShape kind={part.kind} variant="muted" />
            </g>
          );
        })
      ) : (
        <g>
          <rect x={46} y={70} width={108} height={84} rx={6} fill="none" stroke={MUTED} strokeWidth={1.5} strokeDasharray="5 4" />
          <text x={100} y={168} textAnchor="middle" fill={MUTED} fontSize={9} fontFamily="ui-monospace, monospace">
            WORK SURFACE
          </text>
        </g>
      )}

      {shown.map((part, index) => {
        const y = rows[index];
        const startX = 232 - 30 * scale;
        const endX = TARGET.x + 30;
        const endY = TARGET.y + (y - TARGET.y) * 0.25;
        const midX = (startX + endX) / 2;
        const text = calloutText(part);
        const width = text.length * 6 + 14;
        const calloutY = y - 30 * scale - 15;
        return (
          <g key={`${part.label}-${index}`}>
            <path
              d={`M${startX} ${y} Q${midX} ${y}, ${endX} ${endY}`}
              fill="none"
              stroke={ARROW}
              strokeWidth={2.5}
              strokeLinecap="round"
              strokeDasharray={action === 'connect' ? '6 4' : undefined}
              markerEnd={`url(#${id}-head)`}
            />
            <g transform={`translate(256 ${y}) scale(${scale})`}>
              <PartShape kind={part.kind} variant="active" />
            </g>
            <g>
              <rect
                x={Math.min(256 - width / 2, 312 - width)}
                y={calloutY}
                width={width}
                height={15}
                rx={7.5}
                fill="#FFFFFF"
                stroke={INK}
                strokeWidth={1.5}
              />
              <text
                x={Math.min(256, 312 - width / 2)}
                y={calloutY + 10.5}
                textAnchor="middle"
                fill={INK}
                fontSize={9}
                fontFamily="ui-monospace, monospace"
                fontWeight={700}
              >
                {text}
              </text>
            </g>
          </g>
        );
      })}

      <ActionMark action={action} />

      {hidden > 0 && (
        <text x={310} y={194} textAnchor="end" fill={INK} fontSize={9} fontFamily="ui-monospace, monospace">
          +{hidden} more
        </text>
      )}
    </svg>
  );
}
