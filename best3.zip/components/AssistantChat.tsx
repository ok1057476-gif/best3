'use client';

import { useState } from 'react';
import { Bot, Send, X } from 'lucide-react';
import type { Blueprint, BuildStep } from '@/types/blueprint';
import type { Translation } from '@/utils/i18n';

interface AssistantChatProps {
  blueprint: Blueprint;
  checkedPartIds: string[];
  userName: string;
  activeStep: BuildStep | null;
  t: Translation;
  onClearActiveStep: () => void;
  onUpdateBlueprint: (updated: Blueprint) => void;
}

interface Message {
  id: number;
  role: 'user' | 'assistant';
  text: string;
}

export function AssistantChat({
  blueprint,
  checkedPartIds,
  userName,
  activeStep,
  t,
  onClearActiveStep,
}: AssistantChatProps) {
  const [input, setInput] = useState('');
  const [isInputActive, setIsInputActive] = useState(false);
  const [messages, setMessages] = useState<Message[]>(() => [
    {
      id: 0,
      role: 'assistant',
      text: `Hi${userName ? ` ${userName}` : ''}! I can help with "${blueprint.title}". Ask me about parts, wiring, or the code.`,
    },
  ]);

  const send = () => {
    const text = input.trim();
    if (!text) return;
    const context = activeStep ? ` on step ${activeStep.number} (${activeStep.title})` : '';
    const totalParts = blueprint.parts.electronics.length + blueprint.parts.enclosureCraft.length;
    setMessages((prev) => [
      ...prev,
      { id: prev.length, role: 'user', text },
      {
        id: prev.length + 1,
        role: 'assistant',
        text: `Placeholder reply${context}: you have ${checkedPartIds.length} of ${totalParts} parts ready. Double-check your ground connections first — it fixes most beginner issues.`,
      },
    ]);
    setInput('');
  };

  return (
    <section aria-labelledby="assistant-title" className="mt-10 rounded-2xl border border-line bg-surface">
      <div className="flex items-center gap-2 border-b border-line px-5 py-3">
        <Bot
          className={`size-5 ${isInputActive || input ? '' : 'helper-wave'}`}
          style={{ color: 'var(--phenom-accent)' }}
          aria-hidden="true"
        />
        <h2 id="assistant-title" className="font-bold">
          {t.assistantTitle}
        </h2>
      </div>

      {activeStep && (
        <div className="flex items-center justify-between gap-2 border-b border-line bg-sunken px-5 py-2 text-sm">
          <span>
            {t.helpingWith} {activeStep.number}: <strong>{activeStep.title}</strong>
          </span>
          <button
            type="button"
            onClick={onClearActiveStep}
            aria-label={t.close}
            className="-my-2 flex size-12 cursor-pointer items-center justify-center rounded hover:bg-surface md:my-0 md:size-6"
          >
            <X className="size-3.5" aria-hidden="true" />
          </button>
        </div>
      )}

      <ul className="flex max-h-80 flex-col gap-3 overflow-y-auto p-5" aria-live="polite">
        {messages.map((message) => (
          <li
            key={message.id}
            className={`max-w-[85%] rounded-2xl px-4 py-2.5 text-pretty ${
              message.role === 'user' ? 'self-end bg-stone-900 text-paper' : 'self-start bg-sunken'
            }`}
          >
            {message.text}
          </li>
        ))}
      </ul>

      <form
        onSubmit={(e) => {
          e.preventDefault();
          send();
        }}
        className="flex gap-2 border-t border-line p-3"
      >
        <label htmlFor="assistant-input" className="sr-only">
          {t.assistantPlaceholder}
        </label>
        <input
          id="assistant-input"
          value={input}
          onFocus={() => setIsInputActive(true)}
          onBlur={() => setIsInputActive(false)}
          onChange={(e) => setInput(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && (e.nativeEvent.isComposing || e.keyCode === 229)) e.preventDefault();
          }}
          placeholder={t.assistantPlaceholder}
          className="h-12 min-w-0 flex-1 rounded-lg border border-line bg-paper px-3 py-2 outline-none focus:border-stone-400 md:h-auto"
        />
        <button
          type="submit"
          disabled={!input.trim()}
          className="flex min-h-12 min-w-12 cursor-pointer items-center justify-center gap-1.5 rounded-lg px-4 py-3 font-semibold text-white hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-50 md:min-h-0 md:py-2"
          style={{ backgroundColor: 'var(--phenom-accent)' }}
        >
          <Send className="size-4" aria-hidden="true" />
          <span className="sr-only sm:not-sr-only">{t.send}</span>
        </button>
      </form>
    </section>
  );
}
