import type { Blueprint, BuildStep, Part } from '@/types/blueprint';

export interface MockBlueprintInput {
  idea: string;
  budget?: number;
  comfortLevel?: 'beginner' | 'ready_to_learn';
  enclosurePreference?: string;
}

type Feature = 'motion' | 'light' | 'sensor' | 'sound' | 'button';

const FEATURE_KEYWORDS: Record<Feature, RegExp> = {
  motion: /walk|move|wave|spin|turn|rotate|drive|roll|wag|flap|dance|feed|open|arm|leg|robot|crawl|jump/i,
  light: /light|glow|led|lamp|shine|blink|flash|star|neon|night|eye|rainbow|color|colour/i,
  sensor: /sens|detect|plant|soil|temp|humid|motion|distance|proximity|weather|monitor|measure|track/i,
  sound: /sound|beep|buzz|music|song|alarm|sing|meow|bark|chirp|tone|speaker/i,
  button: /button|press|switch|toggle|push|click|remote|control/i,
};

const STOP_WORDS = new Set(['a', 'an', 'the', 'that', 'which', 'with', 'and', 'or', 'for', 'to', 'of', 'my', 'i', 'want', 'make', 'build', 'can', 'it']);

function detectFeatures(idea: string): Feature[] {
  const found = (Object.keys(FEATURE_KEYWORDS) as Feature[]).filter((feature) => FEATURE_KEYWORDS[feature].test(idea));
  return found.length > 0 ? found : ['light', 'button'];
}

function toTitle(idea: string): string {
  const words = idea
    .replace(/[^\p{L}\p{N}\s-]/gu, ' ')
    .split(/\s+/)
    .filter(Boolean);
  const meaningful = words.filter((word) => !STOP_WORDS.has(word.toLowerCase()));
  const chosen = (meaningful.length > 0 ? meaningful : words).slice(0, 5);
  if (chosen.length === 0) return 'Custom Maker Project';
  return chosen.map((word) => word.charAt(0).toUpperCase() + word.slice(1).toLowerCase()).join(' ');
}

function hashString(value: string): string {
  let hash = 0;
  for (let index = 0; index < value.length; index++) hash = (hash * 31 + value.charCodeAt(index)) | 0;
  return Math.abs(hash).toString(36);
}

export function buildMockBlueprint(input: MockBlueprintInput): Blueprint {
  const idea = input.idea.trim() || 'custom maker project';
  const features = detectFeatures(idea);
  const has = (feature: Feature) => features.includes(feature);
  const title = toTitle(idea);
  const key = hashString(idea);
  const usesCardboard = !/3d|print|wood|acrylic/i.test(input.enclosurePreference ?? '');

  const electronics: Part[] = [
    { id: `el-${key}-board`, name: 'Arduino Nano (USB-C clone)', quantity: 1, estimatedPriceUsd: 6, note: 'The brain of the project' },
    { id: `el-${key}-breadboard`, name: 'Mini breadboard (170 points)', quantity: 1, estimatedPriceUsd: 2 },
    { id: `el-${key}-jumpers`, name: 'Jumper wires (male-male)', quantity: 10, estimatedPriceUsd: 0.1 },
    { id: `el-${key}-battery`, name: '4xAA battery holder with switch', quantity: 1, estimatedPriceUsd: 2.5, note: 'Add 4 AA batteries' },
  ];
  if (has('motion')) {
    const count = /walk|leg|crawl/i.test(idea) ? 2 : 1;
    electronics.push({ id: `el-${key}-servo`, name: 'SG90 micro servo', quantity: count, estimatedPriceUsd: 2.5, note: count > 1 ? 'One per pair of legs' : undefined });
  }
  if (has('light')) electronics.push({ id: `el-${key}-led`, name: 'WS2812B LED strip (8 LEDs)', quantity: 1, estimatedPriceUsd: 3 });
  if (has('sensor')) electronics.push({ id: `el-${key}-sensor`, name: /plant|soil/i.test(idea) ? 'Capacitive soil moisture sensor' : 'HC-SR04 ultrasonic distance sensor', quantity: 1, estimatedPriceUsd: 2.5 });
  if (has('sound')) electronics.push({ id: `el-${key}-buzzer`, name: 'Passive piezo buzzer', quantity: 1, estimatedPriceUsd: 0.8 });
  if (has('button')) electronics.push({ id: `el-${key}-button`, name: '12mm tactile push button', quantity: 1, estimatedPriceUsd: 0.4 });

  const enclosureCraft: Part[] = [
    usesCardboard
      ? { id: `ec-${key}-body`, name: 'Sturdy cardboard (shoebox or cereal box)', quantity: 1, estimatedPriceUsd: 0, note: 'Upcycled' }
      : { id: `ec-${key}-body`, name: 'Craft plywood sheet (3mm, A4)', quantity: 1, estimatedPriceUsd: 4 },
    { id: `ec-${key}-glue`, name: 'Hot glue sticks', quantity: 4, estimatedPriceUsd: 0.25 },
    { id: `ec-${key}-tape`, name: 'Double-sided foam tape', quantity: 1, estimatedPriceUsd: 1.5 },
    { id: `ec-${key}-screws`, name: 'M2 screws', quantity: 4, estimatedPriceUsd: 0.1 },
  ];
  if (has('motion')) enclosureCraft.push({ id: `ec-${key}-sticks`, name: 'Popsicle sticks (for linkages)', quantity: 6, estimatedPriceUsd: 0.05 });

  const steps: Omit<BuildStep, 'number'>[] = [
    {
      phase: 'Prep & Cutting',
      title: 'Gather and sort your parts',
      description: 'Lay every part from the shopping list on a clear table. Group electronics on one side and craft materials on the other so nothing goes missing.',
      tip: 'A muffin tray makes a great parts organizer.',
      durationMinutes: 5,
      action: 'place',
      parts: [{ label: 'Nano', kind: 'board', quantity: 1 }, { label: 'Breadboard', kind: 'panel', quantity: 1 }],
    },
    {
      phase: 'Prep & Cutting',
      title: `Cut the body panels for your ${title.toLowerCase()}`,
      description: 'Mark a base panel and two side panels with a pencil and ruler, then cut them out. Always cut away from your body with a sharp craft knife on a cutting mat.',
      tip: 'Several light passes are safer than one hard cut.',
      durationMinutes: 15,
      action: 'cut',
      parts: [{ label: 'Panel A', kind: 'panel', quantity: 1 }, { label: 'Panels B', kind: 'panel', quantity: 2 }],
    },
    {
      phase: 'Prep & Cutting',
      title: 'Assemble the body frame',
      description: 'Glue the side panels to the base panel to form an open box. Hold each joint for 20 seconds while the glue sets.',
      tip: 'Hot glue is hot! Keep fingers away from the nozzle and fresh glue.',
      durationMinutes: 10,
      action: 'glue',
      parts: [{ label: 'Panel A', kind: 'panel', quantity: 1 }, { label: 'Panels B', kind: 'panel', quantity: 2 }],
    },
    {
      phase: 'Wiring',
      title: 'Seat the Arduino on the breadboard',
      description: 'Make sure the battery pack is switched OFF. Press the Arduino Nano into the breadboard so it straddles the center gap, with the USB port facing outward.',
      tip: 'Press gently and evenly on both edges so no pins bend.',
      durationMinutes: 5,
      action: 'snap',
      parts: [{ label: 'Nano', kind: 'board', quantity: 1 }, { label: 'Breadboard', kind: 'panel', quantity: 1 }],
    },
    {
      phase: 'Wiring',
      title: 'Wire the power rails',
      description: 'Connect the Nano 5V pin to the red (+) rail and a GND pin to the blue (-) rail using two jumper wires.',
      tip: 'Red for power and black for ground keeps wiring easy to check.',
      durationMinutes: 5,
      action: 'connect',
      parts: [{ label: 'x2 Jumpers', kind: 'wire', quantity: 2 }],
    },
  ];

  if (has('motion')) {
    steps.push({
      phase: 'Wiring',
      title: 'Connect the servo motor',
      description: 'Plug the servo brown wire into GND, red into 5V, and orange (signal) into pin D9.',
      tip: 'If the servo jitters later, check the brown wire is firmly in the ground rail.',
      durationMinutes: 8,
      action: 'connect',
      parts: [{ label: 'Servo', kind: 'servo', quantity: 1 }, { label: 'x3 Jumpers', kind: 'wire', quantity: 3 }],
    });
  }
  if (has('light')) {
    steps.push({
      phase: 'Wiring',
      title: 'Connect the LED strip',
      description: 'Wire the LED strip 5V to the red rail, GND to the blue rail, and DIN to pin D6.',
      tip: 'Check the little arrow on the strip — data must flow in the arrow direction.',
      durationMinutes: 8,
      action: 'connect',
      parts: [{ label: 'LED strip', kind: 'led', quantity: 1 }, { label: 'x3 Jumpers', kind: 'wire', quantity: 3 }],
    });
  }
  if (has('sensor')) {
    steps.push({
      phase: 'Wiring',
      title: 'Connect the sensor',
      description: /plant|soil/i.test(idea)
        ? 'Wire the soil sensor VCC to 5V, GND to ground, and AOUT to pin A0.'
        : 'Wire the distance sensor VCC to 5V, GND to ground, TRIG to D10, and ECHO to D11.',
      durationMinutes: 8,
      action: 'connect',
      parts: [{ label: 'Sensor', kind: 'sensor', quantity: 1 }, { label: 'x4 Jumpers', kind: 'wire', quantity: 4 }],
    });
  }
  if (has('sound')) {
    steps.push({
      phase: 'Wiring',
      title: 'Add the buzzer',
      description: 'Plug the buzzer into the breadboard. Connect its + leg to pin D5 and the other leg to GND.',
      durationMinutes: 5,
      action: 'connect',
      parts: [{ label: 'Buzzer', kind: 'button', quantity: 1 }, { label: 'x2 Jumpers', kind: 'wire', quantity: 2 }],
    });
  }
  if (has('button')) {
    steps.push({
      phase: 'Wiring',
      title: 'Add the push button',
      description: 'Place the button across the center gap. Wire one leg to pin D2 and the diagonal leg to GND.',
      tip: 'The code uses the internal pull-up, so no resistor is needed.',
      durationMinutes: 5,
      action: 'connect',
      parts: [{ label: 'Button', kind: 'button', quantity: 1 }, { label: 'x2 Jumpers', kind: 'wire', quantity: 2 }],
    });
  }

  steps.push({
    phase: 'Code & Test',
    title: 'Upload the code',
    description: 'Connect the Nano to your computer with a USB-C cable, open the Code tab, copy the sketch into the Arduino IDE, and click Upload.',
    tip: 'Select "Arduino Nano" and the "ATmega328P (Old Bootloader)" processor if the upload fails.',
    durationMinutes: 10,
    action: 'test',
    parts: [{ label: 'Nano', kind: 'board', quantity: 1 }],
  });
  steps.push({
    phase: 'Code & Test',
    title: 'Run a bench test',
    description: 'Before mounting anything, watch each part work while still on the table. Unplug USB before changing any wire.',
    durationMinutes: 5,
    action: 'test',
    parts: [{ label: 'Circuit', kind: 'board', quantity: 1 }],
  });

  steps.push({
    phase: 'Final Assembly',
    title: 'Mount the electronics inside the body',
    description: 'Stick the breadboard and battery pack to the base panel with foam tape. Keep the USB port reachable for future updates.',
    durationMinutes: 8,
    action: 'place',
    parts: [{ label: 'Breadboard', kind: 'panel', quantity: 1 }, { label: 'Battery', kind: 'battery', quantity: 1 }, { label: 'Foam tape', kind: 'tape', quantity: 1 }],
  });
  if (has('motion')) {
    steps.push({
      phase: 'Final Assembly',
      title: 'Attach the moving linkage',
      description: 'Screw the servo into the side panel, then glue popsicle sticks to the servo horn to create the moving part (legs, arm, or lid).',
      tip: 'Center the servo first (the code does this on start-up) before gluing the horn.',
      durationMinutes: 15,
      action: 'screw',
      parts: [{ label: 'Servo', kind: 'servo', quantity: 1 }, { label: 'x4 Screws', kind: 'screw', quantity: 4 }],
    });
  }
  if (has('light')) {
    steps.push({
      phase: 'Final Assembly',
      title: 'Slot the LEDs into place',
      description: 'Cut a thin slot in the front panel and slide the LED strip through so the lights face outward. Secure with a dab of glue.',
      durationMinutes: 8,
      action: 'slot',
      parts: [{ label: 'LED strip', kind: 'led', quantity: 1 }, { label: 'Panel A', kind: 'panel', quantity: 1 }],
    });
  }
  steps.push({
    phase: 'Final Assembly',
    title: 'Close up and final test',
    description: `Switch on the battery pack and watch your ${title.toLowerCase()} come to life. Decorate the outside however you like!`,
    tip: 'Switch the battery pack off when not in use to save power.',
    durationMinutes: 10,
    action: 'test',
    parts: [{ label: 'Battery', kind: 'battery', quantity: 1 }],
  });

  const totalMinutes = steps.reduce((sum, step) => sum + step.durationMinutes, 0);
  const numberedSteps: BuildStep[] = steps.map((step, index) => ({
    ...step,
    number: index + 1,
    phase: steps.length > 8 ? step.phase : 'Build',
  }));

  return {
    id: `mock-${key}-${Date.now()}`,
    title,
    tagline: `A beginner-friendly build inspired by "${idea.slice(0, 80)}".`,
    difficulty: features.length >= 3 || input.comfortLevel === 'ready_to_learn' ? 'Intermediate' : 'Beginner',
    estimatedTime: totalMinutes >= 90 ? `${Math.round(totalMinutes / 30) / 2} hours` : `${totalMinutes} minutes`,
    parts: { electronics, enclosureCraft },
    steps: numberedSteps,
    code: {
      language: 'cpp',
      filename: `${title.toLowerCase().replace(/\s+/g, '_') || 'project'}.ino`,
      source: buildSketch(features, idea),
    },
  };
}

function buildSketch(features: Feature[], idea: string): string {
  const has = (feature: Feature) => features.includes(feature);
  const isSoil = /plant|soil/i.test(idea);
  const lines: string[] = [`// Auto-generated starter sketch for: ${idea.slice(0, 60).replace(/\n/g, ' ')}`];

  if (has('motion')) lines.push('#include <Servo.h>');
  if (has('light')) lines.push('#include <Adafruit_NeoPixel.h>');
  lines.push('');
  if (has('motion')) lines.push('const int SERVO_PIN = 9;', 'Servo mainServo;');
  if (has('light')) lines.push('const int LED_PIN = 6;', 'const int LED_COUNT = 8;', 'Adafruit_NeoPixel strip(LED_COUNT, LED_PIN, NEO_GRB + NEO_KHZ800);');
  if (has('sensor') && isSoil) lines.push('const int SENSOR_PIN = A0;');
  if (has('sensor') && !isSoil) lines.push('const int TRIG_PIN = 10;', 'const int ECHO_PIN = 11;');
  if (has('sound')) lines.push('const int BUZZER_PIN = 5;');
  if (has('button')) lines.push('const int BUTTON_PIN = 2;');

  lines.push('', 'void setup() {', '  Serial.begin(9600);');
  if (has('motion')) lines.push('  mainServo.attach(SERVO_PIN);', '  mainServo.write(90);');
  if (has('light')) lines.push('  strip.begin();', '  strip.setBrightness(60);', '  strip.show();');
  if (has('sensor') && !isSoil) lines.push('  pinMode(TRIG_PIN, OUTPUT);', '  pinMode(ECHO_PIN, INPUT);');
  if (has('sound')) lines.push('  pinMode(BUZZER_PIN, OUTPUT);');
  if (has('button')) lines.push('  pinMode(BUTTON_PIN, INPUT_PULLUP);');
  lines.push('}', '');

  if (has('sensor') && !isSoil) {
    lines.push(
      'long readDistanceCm() {',
      '  digitalWrite(TRIG_PIN, LOW);',
      '  delayMicroseconds(2);',
      '  digitalWrite(TRIG_PIN, HIGH);',
      '  delayMicroseconds(10);',
      '  digitalWrite(TRIG_PIN, LOW);',
      '  return pulseIn(ECHO_PIN, HIGH, 30000) / 58;',
      '}',
      ''
    );
  }

  lines.push('void loop() {');
  const triggers: string[] = [];
  if (has('button')) triggers.push('digitalRead(BUTTON_PIN) == LOW');
  if (has('sensor') && isSoil) triggers.push('analogRead(SENSOR_PIN) > 600');
  if (has('sensor') && !isSoil) triggers.push('(readDistanceCm() > 0 && readDistanceCm() < 20)');
  const condition = triggers.length > 0 ? triggers.join(' || ') : 'true';

  lines.push(`  bool active = ${condition};`, '', '  if (active) {');
  if (has('motion')) lines.push('    for (int angle = 60; angle <= 120; angle += 5) { mainServo.write(angle); delay(15); }', '    for (int angle = 120; angle >= 60; angle -= 5) { mainServo.write(angle); delay(15); }');
  if (has('light')) lines.push('    for (int i = 0; i < LED_COUNT; i++) strip.setPixelColor(i, strip.ColorHSV((millis() * 20 + i * 8192) % 65536));', '    strip.show();');
  if (has('sound')) lines.push('    tone(BUZZER_PIN, 880, 120);');
  lines.push('  } else {');
  if (has('motion')) lines.push('    mainServo.write(90);');
  if (has('light')) lines.push('    strip.clear();', '    strip.show();');
  lines.push('  }', '', '  delay(20);', '}');

  return lines.join('\n');
}
