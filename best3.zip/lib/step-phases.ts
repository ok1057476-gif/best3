import type { BuildStep } from '@/types/blueprint';

export const PHASE_THRESHOLD = 8;
const TARGET_PHASE_SIZE = 5;

export interface StepPhase {
  name: string | null;
  steps: BuildStep[];
}

export function groupStepsIntoPhases(steps: BuildStep[]): StepPhase[] {
  if (steps.length <= PHASE_THRESHOLD) return [{ name: null, steps }];

  if (steps.every((step) => step.phase?.trim())) {
    return steps.reduce<StepPhase[]>((phases, step) => {
      const current = phases.at(-1);
      if (current && current.name === step.phase) current.steps.push(step);
      else phases.push({ name: step.phase!.trim(), steps: [step] });
      return phases;
    }, []);
  }

  const phaseCount = Math.ceil(steps.length / TARGET_PHASE_SIZE);
  const size = Math.ceil(steps.length / phaseCount);
  return Array.from({ length: phaseCount }, (_, index) => ({
    name: null,
    steps: steps.slice(index * size, (index + 1) * size),
  })).filter((phase) => phase.steps.length > 0);
}
