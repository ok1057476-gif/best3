import type { BuildStep, StepPart, StepPartKind } from '@/types/blueprint';

export type Vec3 = [number, number, number];

export const COS30 = Math.cos(Math.PI / 6);

export function project([x, y, z]: Vec3): [number, number] {
  return [(x - y) * COS30, (x + y) * 0.5 - z];
}

export function toPoints(points: Vec3[]) {
  return points
    .map((point) => {
      const [sx, sy] = project(point);
      return `${sx.toFixed(2)},${sy.toFixed(2)}`;
    })
    .join(' ');
}

export function isoEllipse(radius: number) {
  return { rx: radius * Math.SQRT2 * COS30, ry: radius * Math.SQRT2 * 0.5 };
}

function parseHex(hex: string) {
  const value = hex.replace('#', '');
  return [0, 2, 4].map((offset) => parseInt(value.slice(offset, offset + 2), 16));
}

export function mix(from: string, to: string, amount: number) {
  const a = parseHex(from);
  const b = parseHex(to);
  return `#${a
    .map((channel, index) => Math.round(channel + (b[index] - channel) * amount).toString(16).padStart(2, '0'))
    .join('')}`;
}

export const PART_FOOTPRINT: Record<StepPartKind, [number, number]> = {
  board: [60, 40],
  panel: [70, 50],
  screw: [40, 12],
  wire: [64, 26],
  sensor: [40, 20],
  battery: [46, 26],
  led: [16, 16],
  servo: [54, 20],
  button: [26, 26],
  tape: [36, 36],
  container: [60, 44],
};

export const PART_HEIGHT: Record<StepPartKind, number> = {
  board: 9,
  panel: 4,
  screw: 17,
  wire: 4,
  sensor: 11,
  battery: 21,
  led: 24,
  servo: 32,
  button: 11,
  tape: 10,
  container: 34,
};

export interface Placement {
  key: string;
  part: StepPart;
  x: number;
  y: number;
  z: number;
}

const ASSEMBLY_SLOTS: [number, number][] = [
  [0, 0],
  [-45, -25],
  [45, -25],
  [-45, 30],
  [45, 30],
  [0, -45],
];

const MAX_STACK_BASE = 30;

export function layoutAssembly(steps: BuildStep[]) {
  const stackHeights = ASSEMBLY_SLOTS.map(() => 0);
  const placementsByStep = new Map<number, Placement[]>();
  let cursor = 0;

  for (const step of steps) {
    const placements = (step.parts ?? []).map((part, index) => {
      const slot = cursor % ASSEMBLY_SLOTS.length;
      cursor += 1;
      const [x, y] = ASSEMBLY_SLOTS[slot];
      const z = stackHeights[slot] > MAX_STACK_BASE ? 0 : stackHeights[slot];
      stackHeights[slot] = z + PART_HEIGHT[part.kind];
      return { key: `${step.number}-${index}`, part, x, y, z };
    });
    placementsByStep.set(step.number, placements);
  }

  return placementsByStep;
}

export function byDepth(a: Placement, b: Placement) {
  return a.x + a.y - (b.x + b.y) || a.z - b.z;
}

export function partCallout(part: StepPart) {
  return part.quantity > 1 ? `x${part.quantity} ${part.label}` : part.label;
}
