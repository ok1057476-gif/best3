export interface Part {
  id: string;
  name: string;
  quantity: number;
  estimatedPriceUsd: number;
  note?: string;
}

export const STEP_PART_KINDS = [
  'board',
  'panel',
  'screw',
  'wire',
  'sensor',
  'battery',
  'led',
  'servo',
  'button',
  'tape',
  'container',
] as const;

export const STEP_ACTIONS = ['place', 'snap', 'screw', 'slot', 'connect', 'glue', 'cut', 'test'] as const;

export type StepPartKind = (typeof STEP_PART_KINDS)[number];
export type StepAction = (typeof STEP_ACTIONS)[number];

export interface StepPart {
  label: string;
  kind: StepPartKind;
  quantity: number;
}

export interface BuildStep {
  number: number;
  title: string;
  description: string;
  tip?: string;
  durationMinutes: number;
  phase?: string;
  action?: StepAction;
  parts?: StepPart[];
}

export interface Blueprint {
  id: string;
  title: string;
  tagline: string;
  difficulty: 'Beginner' | 'Intermediate';
  estimatedTime: string;
  parts: {
    electronics: Part[];
    enclosureCraft: Part[];
  };
  steps: BuildStep[];
  code: {
    language: string;
    filename: string;
    source: string;
  };
}

export interface ShowcaseProject {
  id: string;
  title: string;
  maker: string;
  description: string;
  likes: number;
  createdAt: string;
  blueprint: Blueprint;
}
