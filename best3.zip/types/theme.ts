export interface AccentTheme {
  id: string;
  name: string;
  hex: string;
}

export const DEFAULT_ACCENT_HEX = '#0F8A5F';

export type ThemePreference = 'light' | 'dark' | 'accent';
export type ResolvedTheme = 'light' | 'dark';

export const THEME_STORAGE_KEY = 'phenom_theme_v1';

export function isThemePreference(value: unknown): value is ThemePreference {
  return value === 'light' || value === 'dark' || value === 'accent';
}

export function readStoredTheme(): ThemePreference {
  const saved = localStorage.getItem(THEME_STORAGE_KEY);
  if (isThemePreference(saved)) return saved;
  // Earlier versions stored 'system'; map it once to the matching explicit mode.
  return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
}

export function resolveTheme(preference: ThemePreference): ResolvedTheme {
  return preference === 'light' ? 'light' : 'dark';
}

export function applyTheme(preference: ThemePreference) {
  const resolved = resolveTheme(preference);
  const root = document.documentElement;
  root.classList.toggle('dark', resolved === 'dark');
  root.classList.toggle('light', resolved === 'light');
  root.classList.toggle('theme-accent', preference === 'accent');
  root.style.colorScheme = resolved;
  document.querySelector('meta[name="theme-color"]')?.setAttribute('content', resolved === 'dark' ? '#000000' : '#FDFBF7');
}

const LEGACY_ACCENT_HEX: Record<string, string> = {
  emerald: '#0F8A5F',
  tomato: '#D9482B',
  cobalt: '#2F5FD0',
  marigold: '#C98A0B',
  plum: '#8A3F9E',
};

const HEX_PATTERN = /^#[0-9a-f]{6}$/i;

export function getAccentTheme(value: string): AccentTheme {
  if (HEX_PATTERN.test(value)) return { id: value, name: value, hex: value };
  const legacyHex = LEGACY_ACCENT_HEX[value];
  if (legacyHex) return { id: legacyHex, name: legacyHex, hex: legacyHex };
  return { id: DEFAULT_ACCENT_HEX, name: DEFAULT_ACCENT_HEX, hex: DEFAULT_ACCENT_HEX };
}
